import { 
  User, Category, Idea, Review, Comment, Vote, 
  Project, Implementation, Notification, Activity, Role, IdeaStatus, ProjectStatus, ProjectTask 
} from '../types';
import { 
  initialUsers, initialCategories, initialIdeas, 
  initialReviews, initialComments, initialVotes, 
  initialProjects, initialImplementations, initialNotifications, initialActivities 
} from '../data/mockData';

const STORAGE_KEY = 'ideavault_state_v1';

interface AppDatabase {
  users: User[];
  categories: Category[];
  ideas: Idea[];
  reviews: Review[];
  comments: Comment[];
  votes: Vote[];
  projects: Project[];
  implementations: Implementation[];
  notifications: Notification[];
  activities: Activity[];
}

function loadDatabase(): AppDatabase {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Failed to parse IdeaVault local state, falling back to initial data', err);
  }
  return {
    users: initialUsers,
    categories: initialCategories,
    ideas: initialIdeas,
    reviews: initialReviews,
    comments: initialComments,
    votes: initialVotes,
    projects: initialProjects,
    implementations: initialImplementations,
    notifications: initialNotifications,
    activities: initialActivities,
  };
}

function saveDatabase(db: AppDatabase) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch (err) {
    console.error('Failed to save to localStorage', err);
  }
}

// Global in-memory singleton synced to localStorage
let db: AppDatabase = loadDatabase();

export const dataService = {
  resetToDefaults(): void {
    db = {
      users: initialUsers,
      categories: initialCategories,
      ideas: initialIdeas,
      reviews: initialReviews,
      comments: initialComments,
      votes: initialVotes,
      projects: initialProjects,
      implementations: initialImplementations,
      notifications: initialNotifications,
      activities: initialActivities,
    };
    saveDatabase(db);
    window.location.reload();
  },

  // USERS
  getUsers(): User[] {
    return [...db.users];
  },
  getUser(userId: string): User | undefined {
    return db.users.find(u => u.User_ID === userId);
  },
  createUser(userData: Omit<User, 'User_ID' | 'Joined'>): User {
    const newUser: User = {
      ...userData,
      User_ID: `USR-0${db.users.length + 1}`,
      Joined: new Date().toISOString().split('T')[0],
    };
    db.users.push(newUser);
    saveDatabase(db);
    return newUser;
  },
  updateUserRole(userId: string, newRole: Role): User | null {
    const user = db.users.find(u => u.User_ID === userId);
    if (!user) return null;
    user.Role = newRole;
    saveDatabase(db);
    return user;
  },
  toggleUserStatus(userId: string): User | null {
    const user = db.users.find(u => u.User_ID === userId);
    if (!user) return null;
    user.Status = user.Status === 'Active' ? 'Inactive' : 'Active';
    saveDatabase(db);
    return user;
  },

  // CATEGORIES
  getCategories(): Category[] {
    return [...db.categories];
  },
  getCategory(id: string): Category | undefined {
    return db.categories.find(c => c.Category_ID === id);
  },
  createCategory(category: Omit<Category, 'Category_ID'>): Category {
    const newCat: Category = {
      ...category,
      Category_ID: `CAT-00${db.categories.length + 1}`,
    };
    db.categories.push(newCat);
    saveDatabase(db);
    return newCat;
  },
  updateCategory(id: string, updates: Partial<Category>): Category | null {
    const cat = db.categories.find(c => c.Category_ID === id);
    if (!cat) return null;
    Object.assign(cat, updates);
    saveDatabase(db);
    return cat;
  },
  deleteCategory(id: string): boolean {
    const index = db.categories.findIndex(c => c.Category_ID === id);
    if (index === -1) return false;
    db.categories.splice(index, 1);
    saveDatabase(db);
    return true;
  },

  // IDEAS
  getIdeas(): Idea[] {
    return [...db.ideas];
  },
  getIdea(id: string): Idea | undefined {
    return db.ideas.find(i => i.Idea_ID === id);
  },
  createIdea(ideaData: {
    userId: string;
    categoryId: string;
    title: string;
    description: string;
    problem: string;
    solution: string;
    impact: string;
    tags: string[];
    links: string[];
    attachments?: Array<{ id: string; name: string; size: string; type: string }>;
  }): Idea {
    const count = db.ideas.length + 1;
    const ideaId = `IV-2026-00${count < 100 ? count + 100 : count}`;
    const newIdea: Idea = {
      Idea_ID: ideaId,
      User_ID: ideaData.userId,
      Category_ID: ideaData.categoryId,
      Title: ideaData.title,
      Description: ideaData.description,
      Problem_Statement: ideaData.problem,
      Proposed_Solution: ideaData.solution,
      Expected_Impact: ideaData.impact,
      Tags: ideaData.tags,
      Supporting_Links: ideaData.links,
      Attachments: ideaData.attachments || [],
      Status: 'Submitted',
      Created_Date: new Date().toISOString(),
      Updated_Date: new Date().toISOString(),
    };

    db.ideas.unshift(newIdea);

    // Record activity
    db.activities.unshift({
      Activity_ID: `ACT-${Date.now()}`,
      User_ID: ideaData.userId,
      Idea_ID: ideaId,
      Type: 'create',
      Message: `New idea "${newIdea.Title}" was submitted for community discussion.`,
      Created_Date: new Date().toISOString(),
    });

    saveDatabase(db);
    return newIdea;
  },
  updateIdeaStatus(ideaId: string, status: IdeaStatus): Idea | null {
    const idea = db.ideas.find(i => i.Idea_ID === ideaId);
    if (!idea) return null;
    idea.Status = status;
    idea.Updated_Date = new Date().toISOString();

    db.activities.unshift({
      Activity_ID: `ACT-${Date.now()}`,
      User_ID: idea.User_ID,
      Idea_ID: ideaId,
      Type: 'status',
      Message: `Status for "${idea.Title}" changed to "${status}".`,
      Created_Date: new Date().toISOString(),
    });

    // Notify author
    db.notifications.unshift({
      Notification_ID: `NOT-${Date.now()}`,
      User_ID: idea.User_ID,
      Title: `Idea Status Updated: ${status}`,
      Message: `Your idea "${idea.Title}" has progressed to status "${status}".`,
      Type: 'status',
      Link: `idea/${ideaId}`,
      Read: false,
      Created_Date: new Date().toISOString(),
    });

    saveDatabase(db);
    return idea;
  },
  assignReviewer(ideaId: string, reviewerId: string, deadline?: string): Idea | null {
    const idea = db.ideas.find(i => i.Idea_ID === ideaId);
    if (!idea) return null;
    idea.Assigned_Reviewer_ID = reviewerId;
    if (deadline) idea.Review_Deadline = deadline;
    if (idea.Status === 'Submitted' || idea.Status === 'Discussion') {
      idea.Status = 'Under Review';
    }
    idea.Updated_Date = new Date().toISOString();

    const reviewer = db.users.find(u => u.User_ID === reviewerId);
    if (reviewer) {
      db.notifications.unshift({
        Notification_ID: `NOT-${Date.now()}`,
        User_ID: reviewerId,
        Title: 'New Review Assignment',
        Message: `You have been assigned to evaluate "${idea.Title}".`,
        Type: 'review',
        Link: `review/${ideaId}`,
        Read: false,
        Created_Date: new Date().toISOString(),
      });
    }

    saveDatabase(db);
    return idea;
  },

  // REVIEWS
  getReviews(): Review[] {
    return [...db.reviews];
  },
  getReviewByIdea(ideaId: string): Review | undefined {
    return db.reviews.find(r => r.Idea_ID === ideaId);
  },
  submitReview(reviewData: {
    ideaId: string;
    reviewerId: string;
    novelty: number;
    feasibility: number;
    impact: number;
    scalability: number;
    technicalComplexity: number;
    comments: string;
    recommendation: 'Recommend' | 'Needs Revision' | 'Reject';
  }): Review {
    const overall = parseFloat(
      (
        (reviewData.novelty +
          reviewData.feasibility +
          reviewData.impact +
          reviewData.scalability +
          reviewData.technicalComplexity) /
        5
      ).toFixed(1)
    );

    const existingIndex = db.reviews.findIndex(r => r.Idea_ID === reviewData.ideaId);
    const newReview: Review = {
      Review_ID: existingIndex >= 0 ? db.reviews[existingIndex].Review_ID : `REV-0${db.reviews.length + 1}`,
      Idea_ID: reviewData.ideaId,
      Reviewer_ID: reviewData.reviewerId,
      Novelty_Score: reviewData.novelty,
      Feasibility_Score: reviewData.feasibility,
      Impact_Score: reviewData.impact,
      Scalability_Score: reviewData.scalability,
      Technical_Complexity_Score: reviewData.technicalComplexity,
      Overall_Score: overall,
      Comments: reviewData.comments,
      Recommendation: reviewData.recommendation,
      Created_Date: new Date().toISOString(),
    };

    if (existingIndex >= 0) {
      db.reviews[existingIndex] = newReview;
    } else {
      db.reviews.unshift(newReview);
    }

    // Update Idea status if appropriate
    const idea = db.ideas.find(i => i.Idea_ID === reviewData.ideaId);
    if (idea) {
      if (reviewData.recommendation === 'Recommend') {
        idea.Status = 'Under Review'; // Can be selected by admin next
      } else if (reviewData.recommendation === 'Needs Revision') {
        idea.Status = 'Needs Revision';
      } else if (reviewData.recommendation === 'Reject') {
        idea.Status = 'Rejected';
      }
      idea.Updated_Date = new Date().toISOString();

      // Notify idea author
      db.notifications.unshift({
        Notification_ID: `NOT-${Date.now()}`,
        User_ID: idea.User_ID,
        Title: 'Evaluation Received',
        Message: `A reviewer evaluated "${idea.Title}" with score ${overall}/10 (${reviewData.recommendation}).`,
        Type: 'review',
        Link: `idea/${idea.Idea_ID}`,
        Read: false,
        Created_Date: new Date().toISOString(),
      });
    }

    saveDatabase(db);
    return newReview;
  },

  // COMMENTS
  getComments(ideaId?: string): Comment[] {
    if (ideaId) {
      return db.comments.filter(c => c.Idea_ID === ideaId);
    }
    return [...db.comments];
  },
  addComment(ideaId: string, userId: string, text: string, parentCommentId?: string): Comment {
    const newComment: Comment = {
      Comment_ID: `COM-${Date.now()}`,
      Idea_ID: ideaId,
      User_ID: userId,
      Comment_Text: text,
      Comment_Date: new Date().toISOString(),
      Parent_Comment_ID: parentCommentId,
    };
    db.comments.push(newComment);

    const idea = db.ideas.find(i => i.Idea_ID === ideaId);
    if (idea && idea.User_ID !== userId) {
      const commenter = db.users.find(u => u.User_ID === userId);
      db.notifications.unshift({
        Notification_ID: `NOT-${Date.now()}`,
        User_ID: idea.User_ID,
        Title: 'New Comment on Your Idea',
        Message: `${commenter ? commenter.Name : 'Someone'} commented on "${idea.Title}".`,
        Type: 'comment',
        Link: `idea/${ideaId}`,
        Read: false,
        Created_Date: new Date().toISOString(),
      });
    }

    saveDatabase(db);
    return newComment;
  },

  // VOTES
  getVotes(ideaId?: string): Vote[] {
    if (ideaId) {
      return db.votes.filter(v => v.Idea_ID === ideaId);
    }
    return [...db.votes];
  },
  getUserVote(ideaId: string, userId: string): Vote | undefined {
    return db.votes.find(v => v.Idea_ID === ideaId && v.User_ID === userId);
  },
  castVote(ideaId: string, userId: string, type: 'up' | 'down'): { upCount: number; userVote: 'up' | 'down' | null } {
    const existingIndex = db.votes.findIndex(v => v.Idea_ID === ideaId && v.User_ID === userId);
    let finalType: 'up' | 'down' | null = type;

    if (existingIndex >= 0) {
      if (db.votes[existingIndex].Vote_Type === type) {
        // Toggle off
        db.votes.splice(existingIndex, 1);
        finalType = null;
      } else {
        // Switch vote
        db.votes[existingIndex].Vote_Type = type;
        db.votes[existingIndex].Created_Date = new Date().toISOString();
      }
    } else {
      // New vote
      db.votes.push({
        Vote_ID: `VOT-${Date.now()}`,
        Idea_ID: ideaId,
        User_ID: userId,
        Vote_Type: type,
        Created_Date: new Date().toISOString(),
      });
    }

    saveDatabase(db);
    const upCount = db.votes.filter(v => v.Idea_ID === ideaId && v.Vote_Type === 'up').length;
    return { upCount, userVote: finalType };
  },

  // PROJECTS
  getProjects(): Project[] {
    return [...db.projects];
  },
  getProject(projectId: string): Project | undefined {
    return db.projects.find(p => p.Project_ID === projectId);
  },
  getProjectByIdea(ideaId: string): Project | undefined {
    return db.projects.find(p => p.Idea_ID === ideaId);
  },
  createProjectFromIdea(data: {
    ideaId: string;
    projectName: string;
    projectOwnerId: string;
    teamMembers: string[];
    startDate: string;
    targetEndDate: string;
    description: string;
    priority: 'Low' | 'Medium' | 'High' | 'Critical';
  }): { project: Project; implementation: Implementation } {
    const count = db.projects.length + 1;
    const projectId = `PRJ-2026-00${count}`;

    const newProject: Project = {
      Project_ID: projectId,
      Idea_ID: data.ideaId,
      Project_Name: data.projectName,
      Project_Status: 'Planning',
      Project_Owner_ID: data.projectOwnerId,
      Team_Members: data.teamMembers,
      Start_Date: data.startDate,
      Target_End_Date: data.targetEndDate,
      Description: data.description,
      Priority: data.priority,
    };

    db.projects.unshift(newProject);

    // Create linked Implementation record
    const implId = `IMP-2026-00${count}`;
    const newImpl: Implementation = {
      Implementation_ID: implId,
      Project_ID: projectId,
      Progress: 10,
      Start_Date: data.startDate,
      End_Date: data.targetEndDate,
      Milestones: [
        { id: `m-${Date.now()}-1`, name: 'Project Charter & Architecture Approval', phase: 'Planning', completed: true, dueDate: data.startDate },
        { id: `m-${Date.now()}-2`, name: 'Sprint 1 Core MVP Development', phase: 'Development', completed: false, dueDate: '2026-11-15' },
        { id: `m-${Date.now()}-3`, name: 'Integration & Reliability Testing', phase: 'Testing', completed: false, dueDate: '2026-12-01' },
        { id: `m-${Date.now()}-4`, name: 'Campus Production Deployment', phase: 'Deployment', completed: false, dueDate: data.targetEndDate },
      ],
      Tasks: [
        { id: `t-${Date.now()}-1`, title: 'Finalize technical specification and architecture', assigneeId: data.projectOwnerId, dueDate: data.startDate, progress: 100, status: 'Completed' },
        { id: `t-${Date.now()}-2`, title: 'Set up development environment and repositories', assigneeId: data.teamMembers[0] || data.projectOwnerId, dueDate: '2026-10-15', progress: 30, status: 'In Progress' },
        { id: `t-${Date.now()}-3`, title: 'Draft test plan and user acceptance criteria', assigneeId: data.projectOwnerId, dueDate: '2026-10-30', progress: 0, status: 'Pending' },
      ],
      Last_Updated: new Date().toISOString(),
    };

    db.implementations.unshift(newImpl);

    // Update Idea status to 'Project Created' or 'Selected'
    const idea = db.ideas.find(i => i.Idea_ID === data.ideaId);
    if (idea) {
      idea.Status = 'Project Created';
      idea.Updated_Date = new Date().toISOString();

      db.notifications.unshift({
        Notification_ID: `NOT-${Date.now()}`,
        User_ID: idea.User_ID,
        Title: 'Idea Promoted to Project!',
        Message: `Congratulations! "${idea.Title}" was converted into project "${newProject.Project_Name}".`,
        Type: 'project',
        Link: `projects/${projectId}`,
        Read: false,
        Created_Date: new Date().toISOString(),
      });
    }

    saveDatabase(db);
    return { project: newProject, implementation: newImpl };
  },
  updateProjectStatus(projectId: string, status: ProjectStatus): Project | null {
    const project = db.projects.find(p => p.Project_ID === projectId);
    if (!project) return null;
    project.Project_Status = status;

    // Also sync the idea status to 'Implementation' if project is moving forward
    const idea = db.ideas.find(i => i.Idea_ID === project.Idea_ID);
    if (idea && status !== 'Planning') {
      idea.Status = 'Implementation';
    }

    saveDatabase(db);
    return project;
  },

  // IMPLEMENTATIONS
  getImplementations(): Implementation[] {
    return [...db.implementations];
  },
  getImplementationByProject(projectId: string): Implementation | undefined {
    return db.implementations.find(imp => imp.Project_ID === projectId);
  },
  updateImplementationProgress(projectId: string, progress: number): Implementation | null {
    const impl = db.implementations.find(i => i.Project_ID === projectId);
    if (!impl) return null;
    impl.Progress = Math.min(100, Math.max(0, progress));
    impl.Last_Updated = new Date().toISOString();

    const project = db.projects.find(p => p.Project_ID === projectId);
    if (project) {
      if (impl.Progress >= 100) {
        project.Project_Status = 'Completed';
      } else if (impl.Progress >= 80) {
        project.Project_Status = 'Deployment';
      } else if (impl.Progress >= 50) {
        project.Project_Status = 'Testing';
      } else if (impl.Progress >= 20) {
        project.Project_Status = 'Development';
      }
    }

    saveDatabase(db);
    return impl;
  },
  toggleMilestone(projectId: string, milestoneId: string): Implementation | null {
    const impl = db.implementations.find(i => i.Project_ID === projectId);
    if (!impl) return null;
    const milestone = impl.Milestones.find(m => m.id === milestoneId);
    if (!milestone) return null;

    milestone.completed = !milestone.completed;

    // Recalculate progress based on completed milestones & tasks
    const totalMilestones = impl.Milestones.length;
    const completedMilestones = impl.Milestones.filter(m => m.completed).length;
    const milestonePct = (completedMilestones / totalMilestones) * 60; // 60% weight

    const taskAvg = impl.Tasks.length > 0 
      ? impl.Tasks.reduce((acc, t) => acc + t.progress, 0) / impl.Tasks.length 
      : 0;
    const taskPct = (taskAvg / 100) * 40; // 40% weight

    impl.Progress = Math.round(milestonePct + taskPct);
    impl.Last_Updated = new Date().toISOString();

    saveDatabase(db);
    return impl;
  },
  updateTaskProgress(projectId: string, taskId: string, progress: number): Implementation | null {
    const impl = db.implementations.find(i => i.Project_ID === projectId);
    if (!impl) return null;
    const task = impl.Tasks.find(t => t.id === taskId);
    if (!task) return null;

    task.progress = Math.min(100, Math.max(0, progress));
    if (task.progress === 100) {
      task.status = 'Completed';
    } else if (task.progress > 0) {
      task.status = 'In Progress';
    } else {
      task.status = 'Pending';
    }

    // Recalculate overall progress
    const totalMilestones = impl.Milestones.length;
    const completedMilestones = impl.Milestones.filter(m => m.completed).length;
    const milestonePct = totalMilestones > 0 ? (completedMilestones / totalMilestones) * 60 : 0;

    const taskAvg = impl.Tasks.length > 0 
      ? impl.Tasks.reduce((acc, t) => acc + t.progress, 0) / impl.Tasks.length 
      : 0;
    const taskPct = (taskAvg / 100) * 40;

    impl.Progress = Math.round(milestonePct + taskPct);
    impl.Last_Updated = new Date().toISOString();

    saveDatabase(db);
    return impl;
  },
  addTask(projectId: string, task: Omit<ProjectTask, 'id'>): Implementation | null {
    const impl = db.implementations.find(i => i.Project_ID === projectId);
    if (!impl) return null;
    const newTask: ProjectTask = {
      ...task,
      id: `t-${Date.now()}`,
    };
    impl.Tasks.push(newTask);
    saveDatabase(db);
    return impl;
  },

  // NOTIFICATIONS
  getNotifications(userId?: string): Notification[] {
    if (userId) {
      return db.notifications.filter(n => n.User_ID === userId || n.User_ID === 'ALL');
    }
    return [...db.notifications];
  },
  markNotificationRead(notificationId: string): void {
    const notif = db.notifications.find(n => n.Notification_ID === notificationId);
    if (notif) {
      notif.Read = true;
      saveDatabase(db);
    }
  },
  markAllNotificationsRead(userId: string): void {
    db.notifications.forEach(n => {
      if (n.User_ID === userId || n.User_ID === 'ALL') {
        n.Read = true;
      }
    });
    saveDatabase(db);
  },

  // ACTIVITIES
  getActivities(): Activity[] {
    return [...db.activities];
  },

  // AI SIMULATION ENGINE (Client-side mock intelligence)
  getAIInsights(idea: Idea) {
    // Find similar ideas by overlapping tags or title words
    const currentTags = new Set(idea.Tags.map(t => t.toLowerCase()));
    const titleWords = new Set(idea.Title.toLowerCase().split(/\W+/).filter(w => w.length > 3));

    const similar = db.ideas
      .filter(other => other.Idea_ID !== idea.Idea_ID)
      .map(other => {
        let tagMatches = 0;
        other.Tags.forEach(t => {
          if (currentTags.has(t.toLowerCase())) tagMatches++;
        });

        let titleMatches = 0;
        other.Title.toLowerCase().split(/\W+/).forEach(w => {
          if (titleWords.has(w)) titleMatches++;
        });

        const score = Math.min(96, Math.max(38, Math.round((tagMatches * 25) + (titleMatches * 20) + (other.Category_ID === idea.Category_ID ? 20 : 0))));
        return {
          idea: other,
          similarityPercentage: score,
        };
      })
      .filter(item => item.similarityPercentage > 45)
      .sort((a, b) => b.similarityPercentage - a.similarityPercentage)
      .slice(0, 3);

    const isDuplicateRisk = similar.length > 0 && similar[0].similarityPercentage >= 85;

    // Generated executive summary
    const summary = `${idea.Title} targets inefficient resource allocation by deploying a targeted solution (${idea.Proposed_Solution.slice(0, 110)}...). Potential ROI includes significant time or cost reduction with high student and faculty impact.`;

    const category = db.categories.find(c => c.Category_ID === idea.Category_ID);
    const suggestedCategory = category ? `${category.Category_Name} → Specialized Track` : 'Technology & AI';

    return {
      similarIdeas: similar,
      isDuplicateRisk,
      duplicateRiskPercent: similar.length > 0 ? similar[0].similarityPercentage : 18,
      summary,
      suggestedCategory,
      keyStrengths: [
        'Directly addresses a quantified university pain point',
        'Strong cross-disciplinary applicability across campus departments',
        'High student user adoption likelihood based on historical engagement patterns',
      ],
      recommendedNextStep: idea.Status === 'Submitted' 
        ? 'Assign to an expert reviewer in the department.'
        : idea.Status === 'Under Review'
        ? 'Review scores exceed benchmark; proceed to Admin Project Allocation.'
        : 'Monitor Phase milestones against projected campus ROI.'
    };
  }
};
