import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/common/Card';
import { StatusBadge, RoleBadge } from '../components/common/Badge';
import { StatusTimeline } from '../components/common/StatusTimeline';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  Share2,
  Calendar,
  Sparkles,
  Paperclip,
  ExternalLink,
  Star,
  Award,
  ShieldCheck,
  UserCheck,
  FolderKanban,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Send,
  Reply,
  Copy,
} from 'lucide-react';

export const IdeaDetails: React.FC = () => {
  const {
    activeIdeaId,
    currentUser,
    openReviewIdea,
    openImplementation,
    openIdeaDetail,
    setActivePage,
    addToast,
    dataVersion,
    triggerRefresh,
  } = useApp();

  const idea = dataService.getIdea(activeIdeaId || 'IV-2026-00101');
  const allUsers = dataService.getUsers();
  const author = idea ? allUsers.find(u => u.User_ID === idea.User_ID) : null;
  const category = idea ? dataService.getCategory(idea.Category_ID) : null;
  const review = idea ? dataService.getReviewByIdea(idea.Idea_ID) : undefined;
  const reviewer = review ? allUsers.find(u => u.User_ID === review.Reviewer_ID) : null;
  const project = idea ? dataService.getProjectByIdea(idea.Idea_ID) : undefined;
  const comments = dataService.getComments(idea?.Idea_ID);
  const userVote = idea ? dataService.getUserVote(idea.Idea_ID, currentUser.User_ID) : undefined;
  const votes = dataService.getVotes(idea?.Idea_ID);
  const upVotesCount = votes.filter(v => v.Vote_Type === 'up').length;

  // Comment input state
  const [commentText, setCommentText] = useState('');
  const [replyToId, setReplyToId] = useState<string | null>(null);

  // Admin Project Modal
  const [showConvertModal, setShowConvertModal] = useState(false);
  const [projectName, setProjectName] = useState(idea ? `${idea.Title} Pilot` : '');
  const [targetEnd, setTargetEnd] = useState('2026-12-15');
  const [projectPriority, setProjectPriority] = useState<'Low' | 'Medium' | 'High' | 'Critical'>('High');

  // Admin Assign Reviewer Modal
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedReviewerId, setSelectedReviewerId] = useState(
    allUsers.find(u => u.Role === 'Reviewer')?.User_ID || ''
  );

  // AI analysis state
  const aiInsights = idea ? dataService.getAIInsights(idea) : null;

  if (!idea) {
    return (
      <div className="text-center py-16">
        <h2 className="text-lg font-bold">Idea Not Found</h2>
        <Button variant="primary" size="md" onClick={() => setActivePage('discover')} className="mt-4">
          Browse All Ideas
        </Button>
      </div>
    );
  }

  const handleVote = (type: 'up' | 'down') => {
    dataService.castVote(idea.Idea_ID, currentUser.User_ID, type);
    triggerRefresh();
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    dataService.addComment(idea.Idea_ID, currentUser.User_ID, commentText.trim(), replyToId || undefined);
    setCommentText('');
    setReplyToId(null);
    addToast({ title: 'Comment Posted', type: 'success' });
    triggerRefresh();
  };

  const handleConvertProject = (e: React.FormEvent) => {
    e.preventDefault();
    const result = dataService.createProjectFromIdea({
      ideaId: idea.Idea_ID,
      projectName: projectName.trim() || `${idea.Title} Implementation`,
      projectOwnerId: idea.User_ID,
      teamMembers: [idea.User_ID, currentUser.User_ID],
      startDate: new Date().toISOString().split('T')[0],
      targetEndDate: targetEnd,
      description: idea.Proposed_Solution,
      priority: projectPriority,
    });

    setShowConvertModal(false);
    addToast({
      title: 'Project Created Successfully!',
      message: `Project ${result.project.Project_ID} is now under active tracking.`,
      type: 'success',
    });
    triggerRefresh();
    openImplementation(result.project.Project_ID);
  };

  const handleAssignReviewer = () => {
    if (!selectedReviewerId) return;
    dataService.assignReviewer(idea.Idea_ID, selectedReviewerId, '2026-10-31T23:59:59Z');
    setShowAssignModal(false);
    addToast({
      title: 'Reviewer Assigned',
      message: `Idea assigned for formal faculty evaluation.`,
      type: 'success',
    });
    triggerRefresh();
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    addToast({ title: 'Idea Link Copied to Clipboard', type: 'info' });
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-in fade-in duration-300">
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <button
            onClick={() => setActivePage('discover')}
            className="hover:text-indigo-600 dark:hover:text-indigo-400 font-medium"
          >
            Ideas
          </button>
          <span>/</span>
          <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">{idea.Idea_ID}</span>
          <span>/</span>
          <span className="truncate max-w-[200px]">{idea.Title}</span>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleCopyLink} leftIcon={<Copy className="w-3.5 h-3.5" />}>
            Share
          </Button>

          {/* Reviewer Action */}
          {currentUser.Role === 'Reviewer' && (
            <Button
              variant="primary"
              size="sm"
              leftIcon={<Award className="w-4 h-4" />}
              onClick={() => openReviewIdea(idea.Idea_ID)}
            >
              {review ? 'Update Evaluation' : 'Evaluate This Idea'}
            </Button>
          )}

          {/* Admin Actions */}
          {currentUser.Role === 'Admin' && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAssignModal(true)}
                leftIcon={<UserCheck className="w-3.5 h-3.5" />}
              >
                Assign Reviewer
              </Button>

              {!project && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => setShowConvertModal(true)}
                  leftIcon={<FolderKanban className="w-3.5 h-3.5" />}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Approve & Convert to Project
                </Button>
              )}
            </div>
          )}

          {project && (
            <Button
              variant="primary"
              size="sm"
              onClick={() => openImplementation(project.Project_ID)}
              leftIcon={<FolderKanban className="w-3.5 h-3.5" />}
              className="bg-purple-600 hover:bg-purple-700"
            >
              View Active Project Pilot
            </Button>
          )}
        </div>
      </div>

      {/* Main Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="space-y-3 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md">
                {idea.Idea_ID}
              </span>
              <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/70 px-3 py-1 rounded-full uppercase tracking-wider">
                {category?.Category_Name || 'General'}
              </span>
              <StatusBadge status={idea.Status} size="md" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 leading-snug">
              {idea.Title}
            </h1>

            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 leading-relaxed">
              {idea.Description}
            </p>
          </div>

          {/* Upvote Widget */}
          <div className="flex md:flex-col items-center gap-2 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/70 dark:border-slate-800 shrink-0">
            <button
              onClick={() => handleVote('up')}
              className={`p-2.5 rounded-xl transition-all ${
                userVote?.Vote_Type === 'up'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
              title="Upvote Idea"
            >
              <ThumbsUp className="w-5 h-5" />
            </button>
            <span className="text-base font-extrabold text-slate-800 dark:text-slate-200 px-1">
              {upVotesCount}
            </span>
            <button
              onClick={() => handleVote('down')}
              className={`p-2.5 rounded-xl transition-all ${
                userVote?.Vote_Type === 'down'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
              title="Downvote Idea"
            >
              <ThumbsDown className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Metadata Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            {author && (
              <div className="flex items-center gap-2.5">
                <img
                  src={author.Avatar}
                  alt={author.Name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500/20"
                />
                <div>
                  <span className="font-semibold text-slate-900 dark:text-slate-100 block">
                    {author.Name}
                  </span>
                  <span className="text-[11px] text-slate-400">{author.Department}</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Submitted {new Date(idea.Created_Date).toLocaleDateString()}</span>
            </span>

            <span className="flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-slate-400" />
              <span>{comments.length} comments</span>
            </span>
          </div>
        </div>

        {/* Status Lifecycle Timeline */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Innovation Lifecycle Stage
          </div>
          <StatusTimeline status={idea.Status} />
        </div>
      </div>

      {/* Grid: Main Deep Dive vs Sidebar (Evaluation + AI Insights) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 cols): Problem, Solution, Impact, Attachments, Comments */}
        <div className="lg:col-span-2 space-y-6">
          {/* Problem Statement */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-indigo-700 dark:text-indigo-400">
                1. Problem Statement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {idea.Problem_Statement}
              </p>
            </CardContent>
          </Card>

          {/* Proposed Solution */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-indigo-700 dark:text-indigo-400">
                2. Proposed Technical Solution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {idea.Proposed_Solution}
              </p>
            </CardContent>
          </Card>

          {/* Expected Impact */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-indigo-700 dark:text-indigo-400">
                3. Expected Impact & Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {idea.Expected_Impact}
              </p>
            </CardContent>
          </Card>

          {/* Tags & Supporting Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Tags & Documentation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                  Keywords
                </span>
                <div className="flex flex-wrap gap-2">
                  {idea.Tags.map(tag => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/80 dark:border-slate-700"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {idea.Supporting_Links.length > 0 && (
                <div>
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                    Reference URLs
                  </span>
                  <div className="space-y-1.5">
                    {idea.Supporting_Links.map((url, idx) => (
                      <a
                        key={idx}
                        href={url}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{url}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {idea.Attachments.length > 0 && (
                <div>
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                    Attachments & Specs
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {idea.Attachments.map(att => (
                      <div
                        key={att.id}
                        className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-xs"
                      >
                        <div className="flex items-center gap-2 min-w-0 pr-2">
                          <Paperclip className="w-4 h-4 text-indigo-500 shrink-0" />
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                              {att.name}
                            </p>
                            <span className="text-[10px] text-slate-400">{att.size}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => addToast({ title: `Simulated download: ${att.name}`, type: 'info' })}
                          className="shrink-0 text-xs text-indigo-600"
                        >
                          Download
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Community Discussion & Comments Section */}
          <Card id="comments">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-600" />
                Community Discussion ({comments.length})
              </CardTitle>
              <span className="text-xs text-slate-400">Public peer exchange</span>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Comment Input */}
              <form onSubmit={handleAddComment} className="space-y-3">
                {replyToId && (
                  <div className="flex items-center justify-between text-xs px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded-lg">
                    <span>Replying to comment...</span>
                    <button
                      type="button"
                      onClick={() => setReplyToId(null)}
                      className="text-slate-400 hover:text-slate-600"
                    >
                      Cancel
                    </button>
                  </div>
                )}
                <div className="flex gap-3">
                  <img
                    src={currentUser.Avatar}
                    alt={currentUser.Name}
                    className="w-8 h-8 rounded-full object-cover shrink-0 mt-1"
                  />
                  <div className="flex-1">
                    <textarea
                      rows={3}
                      value={commentText}
                      onChange={e => setCommentText(e.target.value)}
                      placeholder={`Add to the discussion as ${currentUser.Name}...`}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                    />
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-[11px] text-slate-400">Be constructive & collaborative</span>
                      <Button
                        type="submit"
                        variant="primary"
                        size="sm"
                        disabled={!commentText.trim()}
                        rightIcon={<Send className="w-3.5 h-3.5 ml-1" />}
                      >
                        Post Comment
                      </Button>
                    </div>
                  </div>
                </div>
              </form>

              {/* Comments List */}
              <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                {comments.length === 0 ? (
                  <p className="text-xs text-center text-slate-400 py-6">
                    No comments yet. Be the first to share feedback or ask a technical question!
                  </p>
                ) : (
                  comments.map(c => {
                    const commenter = allUsers.find(u => u.User_ID === c.User_ID);
                    return (
                      <div
                        key={c.Comment_ID}
                        className={`p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 ${
                          c.Parent_Comment_ID ? 'ml-6 border-l-4 border-l-indigo-500' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <img
                              src={commenter?.Avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                              alt={commenter?.Name}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                              {commenter?.Name || 'User'}
                            </span>
                            <RoleBadge role={commenter?.Role || 'Student'} size="sm" />
                          </div>
                          <span className="text-[11px] text-slate-400">
                            {new Date(c.Comment_Date).toLocaleDateString()}
                          </span>
                        </div>

                        <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                          {c.Comment_Text}
                        </p>

                        <div className="mt-2 flex items-center justify-end">
                          <button
                            type="button"
                            onClick={() => {
                              setReplyToId(c.Comment_ID);
                              setCommentText(`@${commenter?.Name}: `);
                            }}
                            className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                          >
                            <Reply className="w-3 h-3" />
                            Reply
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column (1 col): Reviewer Evaluation Summary + AI Insights */}
        <div className="space-y-6">
          {/* Evaluation Summary Card */}
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  Faculty Evaluation
                </CardTitle>
                <CardDescription>Structured rubric scoring</CardDescription>
              </div>
              {review && (
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    review.Recommendation === 'Recommend'
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                      : review.Recommendation === 'Needs Revision'
                      ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                  }`}
                >
                  {review.Recommendation}
                </span>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {review ? (
                <>
                  {/* Overall Big Score */}
                  <div className="p-4 rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 dark:from-slate-800 dark:to-slate-800/80 border border-amber-200/80 dark:border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                        Composite Score
                      </span>
                      <span className="text-3xl font-extrabold text-amber-600 dark:text-amber-400">
                        {review.Overall_Score}
                        <span className="text-sm font-semibold text-slate-400"> / 10</span>
                      </span>
                    </div>
                    <div className="text-right text-xs text-slate-500">
                      <span className="font-semibold block text-slate-800 dark:text-slate-200">
                        Evaluated By:
                      </span>
                      <span>{reviewer?.Name || 'Faculty Panel'}</span>
                    </div>
                  </div>

                  {/* 5 Scoring Rubric Bars */}
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <div className="flex justify-between font-medium mb-1">
                        <span className="text-slate-600 dark:text-slate-400">Novelty</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {review.Novelty_Score} / 10
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-600 rounded-full"
                          style={{ width: `${review.Novelty_Score * 10}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between font-medium mb-1">
                        <span className="text-slate-600 dark:text-slate-400">Feasibility</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {review.Feasibility_Score} / 10
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-600 rounded-full"
                          style={{ width: `${review.Feasibility_Score * 10}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between font-medium mb-1">
                        <span className="text-slate-600 dark:text-slate-400">Campus Impact</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {review.Impact_Score} / 10
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{ width: `${review.Impact_Score * 10}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between font-medium mb-1">
                        <span className="text-slate-600 dark:text-slate-400">Scalability</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {review.Scalability_Score} / 10
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-600 rounded-full"
                          style={{ width: `${review.Scalability_Score * 10}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between font-medium mb-1">
                        <span className="text-slate-600 dark:text-slate-400">Technical Rigor</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {review.Technical_Complexity_Score} / 10
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-sky-600 rounded-full"
                          style={{ width: `${review.Technical_Complexity_Score * 10}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Reviewer Commentary Quote */}
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-800 text-xs italic text-slate-600 dark:text-slate-300 leading-relaxed">
                    "{review.Comments}"
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-xs text-slate-400">
                    This submission is awaiting faculty peer evaluation.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3 w-full"
                    onClick={() => openReviewIdea(idea.Idea_ID)}
                  >
                    Score this Idea as Reviewer
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* AI Insights & Duplicate Detection (Requirement 18) */}
          {aiInsights && (
            <Card className="border-indigo-200/80 dark:border-indigo-900/40 bg-gradient-to-br from-indigo-50/20 to-white dark:from-slate-900 dark:to-slate-900">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    AI Insights & Analysis
                  </CardTitle>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                    Simulated
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 text-xs">
                {/* Executive Summary */}
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    AI Synthesis Summary:
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed bg-white dark:bg-slate-800/60 p-2.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                    {aiInsights.summary}
                  </p>
                </div>

                {/* Suggested Taxonomy */}
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Suggested Track:
                  </span>
                  <span className="inline-block px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 font-medium text-slate-700 dark:text-slate-300">
                    {aiInsights.suggestedCategory}
                  </span>
                </div>

                {/* Duplicate Risk Check */}
                <div
                  className={`p-3 rounded-xl border ${
                    aiInsights.isDuplicateRisk
                      ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold mb-0.5">
                    {aiInsights.isDuplicateRisk ? (
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    )}
                    <span>
                      {aiInsights.isDuplicateRisk
                        ? 'High Similarity Alert'
                        : 'Uniqueness Verified (Low Overlap)'}
                    </span>
                  </div>
                  <p className="text-[11px] leading-snug">
                    {aiInsights.isDuplicateRisk
                      ? `Potential overlap detected (${aiInsights.duplicateRiskPercent}% max match). Check similar proposals below.`
                      : `Similarity index is under 50%. Proposal brings fresh novelty to the campus repository.`}
                  </p>
                </div>

                {/* Similar Ideas List */}
                {aiInsights.similarIdeas.length > 0 && (
                  <div>
                    <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                      Similar Campus Proposals:
                    </span>
                    <div className="space-y-1.5">
                      {aiInsights.similarIdeas.map(item => (
                        <div
                          key={item.idea.Idea_ID}
                          onClick={() => openIdeaDetail(item.idea.Idea_ID)}
                          className="p-2 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 flex items-center justify-between hover:border-indigo-500 cursor-pointer transition-colors"
                        >
                          <div className="min-w-0 pr-2">
                            <span className="font-semibold text-slate-800 dark:text-slate-200 truncate block">
                              {item.idea.Title}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {item.idea.Idea_ID}
                            </span>
                          </div>
                          <span className="font-bold text-indigo-600 dark:text-indigo-400 shrink-0 text-xs">
                            {item.similarityPercentage}% match
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Admin Convert to Project Modal (Requirement 15) */}
      <Modal
        isOpen={showConvertModal}
        onClose={() => setShowConvertModal(false)}
        title="Promote Idea to Active Project Pilot"
        description="Convert this approved innovation into an tracked implementation project with milestones and team allocation."
      >
        <form onSubmit={handleConvertProject} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Project Name
            </label>
            <input
              type="text"
              required
              value={projectName}
              onChange={e => setProjectName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Project Owner
              </label>
              <input
                type="text"
                disabled
                value={author?.Name || 'Idea Author'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Priority
              </label>
              <select
                value={projectPriority}
                onChange={e => setProjectPriority(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Target Completion Date
            </label>
            <input
              type="date"
              required
              value={targetEnd}
              onChange={e => setTargetEnd(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowConvertModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md" className="bg-emerald-600 hover:bg-emerald-700">
              Create Project Pilot
            </Button>
          </div>
        </form>
      </Modal>

      {/* Admin Assign Reviewer Modal (Requirement 14) */}
      <Modal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        title="Assign Faculty Reviewer"
        description="Select a qualified faculty reviewer from the academic council to score this submission."
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Reviewer
            </label>
            <select
              value={selectedReviewerId}
              onChange={e => setSelectedReviewerId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {allUsers
                .filter(u => u.Role === 'Reviewer')
                .map(rev => (
                  <option key={rev.User_ID} value={rev.User_ID}>
                    {rev.Name} ({rev.Department})
                  </option>
                ))}
            </select>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowAssignModal(false)}>
              Cancel
            </Button>
            <Button type="button" variant="primary" size="md" onClick={handleAssignReviewer}>
              Confirm Assignment
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
