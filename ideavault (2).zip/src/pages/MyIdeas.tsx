import React from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardContent } from '../components/common/Card';
import { StatusBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Plus, ThumbsUp, MessageSquare, Star, ArrowRight, Lightbulb } from 'lucide-react';

export const MyIdeas: React.FC = () => {
  const { currentUser, openIdeaDetail, setActivePage, dataVersion } = useApp();

  const allIdeas = dataService.getIdeas();
  const myIdeas = allIdeas.filter(i => i.User_ID === currentUser.User_ID);
  const categories = dataService.getCategories();
  const reviews = dataService.getReviews();
  const votes = dataService.getVotes();
  const comments = dataService.getComments();

  const getCategoryName = (catId: string) => {
    return categories.find(c => c.Category_ID === catId)?.Category_Name || 'General';
  };

  const getVoteCount = (ideaId: string) => {
    return votes.filter(v => v.Idea_ID === ideaId && v.Vote_Type === 'up').length;
  };

  const getCommentCount = (ideaId: string) => {
    return comments.filter(c => c.Idea_ID === ideaId).length;
  };

  const getReviewScore = (ideaId: string) => {
    const rev = reviews.find(r => r.Idea_ID === ideaId);
    return rev ? rev.Overall_Score : null;
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            My Submitted Ideas
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track the review status, community discussions, and implementation progress of your proposals.
          </p>
        </div>
        <Button
          variant="primary"
          size="md"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setActivePage('submit')}
        >
          Submit New Idea
        </Button>
      </div>

      {myIdeas.length === 0 ? (
        <Card className="text-center p-12">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center mx-auto mb-3">
            <Lightbulb className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            You haven't submitted any ideas yet
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
            Turn your spark of campus innovation into a structured proposal today.
          </p>
          <Button
            variant="primary"
            size="md"
            onClick={() => setActivePage('submit')}
            className="mt-4"
          >
            Create Your First Submission
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {myIdeas.map(idea => {
            const voteCount = getVoteCount(idea.Idea_ID);
            const commentCount = getCommentCount(idea.Idea_ID);
            const score = getReviewScore(idea.Idea_ID);

            return (
              <Card
                key={idea.Idea_ID}
                hoverEffect
                className="cursor-pointer flex flex-col justify-between"
                onClick={() => openIdeaDetail(idea.Idea_ID)}
              >
                <CardContent className="p-5 flex-1">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/70 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      {getCategoryName(idea.Category_ID)}
                    </span>
                    <StatusBadge status={idea.Status} size="sm" />
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 hover:text-indigo-600 transition-colors line-clamp-2">
                    {idea.Title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {idea.Description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mt-3.5">
                    {idea.Tags.map(tag => (
                      <span
                        key={tag}
                        className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </CardContent>

                <div className="p-4 px-5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-mono text-slate-400">{idea.Idea_ID}</span>
                  <div className="flex items-center gap-3">
                    {score !== null && (
                      <span className="flex items-center gap-1 font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded">
                        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                        {score}/10
                      </span>
                    )}
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3.5 h-3.5 text-indigo-500" />
                      {voteCount}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5" />
                      {commentCount}
                    </span>
                    <ArrowRight className="w-4 h-4 text-indigo-600 ml-1" />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
