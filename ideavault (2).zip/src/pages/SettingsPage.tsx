import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { RoleBadge } from '../components/common/Badge';
import {
  User as UserIcon,
  Sun,
  Moon,
  RotateCcw,
  Sparkles,
  Shield,
  Bell,
  Database,
  CheckCircle2,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { currentUser, switchRole, theme, toggleTheme, addToast } = useApp();

  const [emailAlerts, setEmailAlerts] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(true);
  const [peerMentions, setPeerMentions] = useState(true);

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset all data back to the demo defaults? All newly submitted ideas, comments, and project updates will be reset.')) {
      dataService.resetToDefaults();
    }
  };

  const handleSavePreferences = () => {
    addToast({
      title: 'Preferences Updated',
      message: 'Your notification and display preferences were saved.',
      type: 'success',
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Account & Platform Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Manage your profile, theme mode, notification frequency, and demo data state.
        </p>
      </div>

      {/* User Profile Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UserIcon className="w-4 h-4 text-indigo-600" />
            Active User Profile
          </CardTitle>
          <CardDescription>Simulated identity in IdeaVault</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <img
              src={currentUser.Avatar}
              alt={currentUser.Name}
              className="w-16 h-16 rounded-2xl object-cover ring-4 ring-indigo-500/20"
            />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {currentUser.Name}
                </h3>
                <RoleBadge role={currentUser.Role} size="sm" />
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">{currentUser.Email}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                {currentUser.Department} • {currentUser.Title || 'Campus Member'}
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
              Quick Role Switch (Demo Mode):
            </span>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={currentUser.Role === 'Student' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => switchRole('Student')}
              >
                Student (Aarav)
              </Button>
              <Button
                variant={currentUser.Role === 'Reviewer' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => switchRole('Reviewer')}
              >
                Reviewer (Dr. Sarah)
              </Button>
              <Button
                variant={currentUser.Role === 'Admin' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => switchRole('Admin')}
              >
                Admin (Dr. Robert)
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Appearance & Theme Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Appearance & Visual Theme
          </CardTitle>
          <CardDescription>Toggle between clean light and dark workspace themes</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
              Current Theme: {theme === 'light' ? 'Light Theme' : 'Dark Theme'}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              Optimized for high-contrast academic dashboards and data charts.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={toggleTheme}
            leftIcon={theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          >
            Switch to {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
          </Button>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Bell className="w-4 h-4 text-indigo-600" />
            Notification Subscriptions
          </CardTitle>
          <CardDescription>Control alerts for reviews, comments, and status transitions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <label className="flex items-center justify-between text-xs cursor-pointer p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60">
            <div>
              <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                Review & Evaluation Updates
              </span>
              <span className="text-slate-400">Receive immediate notifications when faculty score your idea.</span>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={e => setEmailAlerts(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded accent-indigo-600"
            />
          </label>

          <label className="flex items-center justify-between text-xs cursor-pointer p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60">
            <div>
              <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                Discussion Mentions & Comments
              </span>
              <span className="text-slate-400">Notify when peers ask questions or reply to your threads.</span>
            </div>
            <input
              type="checkbox"
              checked={peerMentions}
              onChange={e => setPeerMentions(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded accent-indigo-600"
            />
          </label>

          <label className="flex items-center justify-between text-xs cursor-pointer p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60">
            <div>
              <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                Weekly Campus Innovation Digest
              </span>
              <span className="text-slate-400">Curated weekly highlights of trending proposals and funded pilots.</span>
            </div>
            <input
              type="checkbox"
              checked={weeklyDigest}
              onChange={e => setWeeklyDigest(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded accent-indigo-600"
            />
          </label>

          <div className="pt-2 flex justify-end">
            <Button variant="primary" size="sm" onClick={handleSavePreferences}>
              Save Preferences
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Demo Seed Reset Card */}
      <Card className="border-rose-200/80 dark:border-rose-900/50">
        <CardHeader>
          <CardTitle className="text-base text-rose-600 flex items-center gap-2">
            <Database className="w-4 h-4" />
            Reset Prototype State
          </CardTitle>
          <CardDescription>
            Restore all pre-populated demo data, users, votes, comments, and milestones back to factory seed settings.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-between">
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md">
            Useful if you want to run through the end-to-end evaluation and approval demo flow from the beginning.
          </p>
          <Button
            variant="danger"
            size="sm"
            onClick={handleResetData}
            leftIcon={<RotateCcw className="w-4 h-4" />}
          >
            Reset All Data
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
