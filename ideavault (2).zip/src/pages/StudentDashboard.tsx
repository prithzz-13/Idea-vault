import React from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { StatusBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import {
  Lightbulb,
  Clock,
  CheckCircle2,
  Rocket,
  Plus,
  Compass,
  ArrowUpRight,
  TrendingUp,
  ThumbsUp,
  MessageSquare,
  Sparkles,
  Award,
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const { currentUser, setActivePage, openIdeaDetail, dataVersion } = useApp();

  const allIdeas = dataService.getIdeas();
  const myIdeas = allIdeas.filter(i => i.User_ID === currentUser.User_ID);
  const categories = dataService.getCategories();
  const votes = dataService.getVotes();
  const comments = dataService.getComments();
  const activities = dataService.getActivities();

  // Metrics
  const totalIdeasCount = allIdeas.length;
  const underReviewCount = allIdeas.filter(i => i.Status === 'Under Review').length;
  const approvedCount = allIdeas.filter(
    i => i.Status === 'Selected' || i.Status === 'Project Created' || i.Status === 'Implementation'
  ).length;
  const implementationCount = allIdeas.filter(i => i.Status === 'Implementation').length;

  const getCategoryName = (catId: string) => {
    return categories.find(c => c.Category_ID === catId)?.Category_Name || 'General';
  };

  const getVoteCount = (ideaId: string) => {
    return votes.filter(v => v.Idea_ID === ideaId && v.Vote_Type === 'up').length;
  };

  const getCommentCount = (ideaId: string) => {
    return comments.filter(c => c.Idea_ID === ideaId).length;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-700 via-indigo-600 to-indigo-800 text-white p-6 sm:p-8 shadow-lg shadow-indigo-600/10">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-indigo-100 text-xs font-semibold backdrop-blur-sm mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Welcome back, {currentUser.Name}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Campus Innovation & Research Hub
          </h1>
          <p className="mt-2 text-sm sm:text-base text-indigo-100/90 leading-relaxed font-normal">
            Submit your novel campus solutions, collaborate with peers across majors, and get evaluated for incubator funding and real pilot implementation.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button
              variant="secondary"
              size="md"
              onClick={() => setActivePage('submit')}
              leftIcon={<Plus className="w-4 h-4 text-indigo-600" />}
              className="bg-white text-indigo-700 hover:bg-slate-100 font-bold"
            >
              Submit New Idea
            </Button>
            <Button
              variant="outline"
              size="md"
              onClick={() => setActivePage('discover')}
              leftIcon={<Compass className="w-4 h-4 text-white" />}
              className="border-white/30 text-white hover:bg-white/10"
            >
              Explore Ideas
            </Button>
            <Button
              variant="ghost"
              size="md"
              onClick={() => setActivePage('my-ideas')}
              className="text-indigo-100 hover:bg-white/10"
            >
              View My Ideas ({myIdeas.length})
            </Button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 4 Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <Card hoverEffect>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Total Ideas</p>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                {totalIdeasCount}
              </h3>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-medium">
                <TrendingUp className="w-3 h-3" />
                <span>+4 this semester</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 flex items-center justify-center shrink-0">
              <Lightbulb className="w-6 h-6" />
            </div>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Ideas Under Review</p>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                {underReviewCount}
              </h3>
              <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-1 flex items-center gap-1 font-medium">
                <Clock className="w-3 h-3" />
                <span>Faculty scoring in progress</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/70 text-amber-600 flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Approved Ideas</p>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                {approvedCount}
              </h3>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-medium">
                <Award className="w-3 h-3" />
                <span>Selected for campus pilot</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">In Implementation</p>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                {implementationCount}
              </h3>
              <p className="text-[11px] text-purple-600 dark:text-purple-400 mt-1 flex items-center gap-1 font-medium">
                <Rocket className="w-3 h-3" />
                <span>Active hardware & code</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-purple-50 dark:bg-purple-950/70 text-purple-600 flex items-center justify-center shrink-0">
              <Rocket className="w-6 h-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Grid: Recent Ideas Table + Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Ideas Table (2 columns wide) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                Recent Campus Ideas
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                High-priority submissions under active community discussion
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setActivePage('discover')}
              rightIcon={<ArrowUpRight className="w-4 h-4" />}
            >
              View All
            </Button>
          </div>

          <Card>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/75 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/80 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Idea Title</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-center">Votes</th>
                    <th className="py-3 px-4 text-center">Comments</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                  {allIdeas.slice(0, 5).map(idea => (
                    <tr
                      key={idea.Idea_ID}
                      className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-semibold text-slate-900 dark:text-slate-100 truncate hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer" onClick={() => openIdeaDetail(idea.Idea_ID)}>
                          {idea.Title}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">
                          {idea.Idea_ID} • {new Date(idea.Created_Date).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                        <span className="truncate max-w-[120px] block">
                          {getCategoryName(idea.Category_ID)}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={idea.Status} size="sm" />
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                          <ThumbsUp className="w-3 h-3 text-indigo-500" />
                          {getVoteCount(idea.Idea_ID)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400">
                          <MessageSquare className="w-3 h-3" />
                          {getCommentCount(idea.Idea_ID)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openIdeaDetail(idea.Idea_ID)}
                          className="text-indigo-600 hover:text-indigo-700 font-medium"
                        >
                          Details
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Activity Feed (1 column wide) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              Live Activity Feed
            </h2>
            <span className="text-[11px] text-slate-400 font-mono">Real-time</span>
          </div>

          <Card>
            <CardContent className="p-4 space-y-4">
              {activities.slice(0, 5).map(act => (
                <div key={act.Activity_ID} className="flex items-start gap-3 text-xs">
                  <div className="w-7 h-7 rounded-full bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 flex items-center justify-center shrink-0 mt-0.5">
                    {act.Type === 'vote' ? (
                      <ThumbsUp className="w-3.5 h-3.5" />
                    ) : act.Type === 'comment' ? (
                      <MessageSquare className="w-3.5 h-3.5" />
                    ) : act.Type === 'project' ? (
                      <Rocket className="w-3.5 h-3.5" />
                    ) : act.Type === 'review' ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                      {act.Message}
                    </p>
                    <span className="text-[11px] text-slate-400 mt-0.5 block">
                      {new Date(act.Created_Date).toLocaleDateString()} at{' '}
                      {new Date(act.Created_Date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Submitter Banner */}
          <div className="p-5 rounded-xl bg-gradient-to-br from-indigo-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 border border-indigo-100 dark:border-slate-800">
            <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wider">
              Have an Idea for Campus?
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
              Every funded campus initiative begins with a 5-minute proposal. Peer feedback opens as soon as you submit.
            </p>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setActivePage('submit')}
              className="mt-3 w-full"
            >
              Start Submission
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
