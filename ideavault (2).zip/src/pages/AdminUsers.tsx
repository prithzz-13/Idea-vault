import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { User, Role } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { RoleBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  Users,
  Plus,
  Search,
  MoreVertical,
  Shield,
  UserX,
  UserCheck,
  CheckCircle2,
  Mail,
  Edit2,
} from 'lucide-react';

export const AdminUsers: React.FC = () => {
  const { addToast, triggerRefresh, dataVersion } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [targetUser, setTargetUser] = useState<User | null>(null);
  const [newRole, setNewRole] = useState<Role>('Student');

  // New user form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('Computer Science');
  const [role, setRole] = useState<Role>('Student');

  const users = dataService.getUsers();
  const ideas = dataService.getIdeas();

  const getUserIdeaCount = (userId: string) => ideas.filter(i => i.User_ID === userId).length;

  const filteredUsers = users.filter(u => {
    const matchesSearch =
      !searchTerm ||
      u.Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.Email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.Department.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRole = roleFilter === 'all' || u.Role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    dataService.createUser({
      Name: name.trim(),
      Email: email.trim(),
      Role: role,
      Avatar: `https://images.unsplash.com/photo-${1534528741775 + users.length * 100}?w=150&auto=format&fit=crop&q=80`,
      Department: department,
      Status: 'Active',
    });

    setShowCreateModal(false);
    setName('');
    setEmail('');
    addToast({
      title: 'User Created',
      message: `${name} has been added as a ${role}.`,
      type: 'success',
    });
    triggerRefresh();
  };

  const handleToggleStatus = (u: User) => {
    dataService.toggleUserStatus(u.User_ID);
    addToast({
      title: `User ${u.Status === 'Active' ? 'Disabled' : 'Activated'}`,
      message: `${u.Name} is now ${u.Status === 'Active' ? 'Inactive' : 'Active'}.`,
      type: 'info',
    });
    triggerRefresh();
  };

  const handleChangeRole = () => {
    if (!targetUser) return;
    dataService.updateUserRole(targetUser.User_ID, newRole);
    setShowRoleModal(false);
    addToast({
      title: 'Role Updated',
      message: `${targetUser.Name} is now assigned the ${newRole} role.`,
      type: 'success',
    });
    triggerRefresh();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            User Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage student innovators, faculty reviewers, and platform administrative privileges.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setShowCreateModal(true)}
        >
          Create User
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search by name, email, or department..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <select
          value={roleFilter}
          onChange={e => setRoleFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm font-semibold focus:outline-none"
        >
          <option value="all">All Roles ({users.length})</option>
          <option value="Student">Students</option>
          <option value="Reviewer">Reviewers</option>
          <option value="Admin">Administrators</option>
        </select>
      </div>

      {/* User Table (Requirement 12) */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/80 dark:border-slate-800">
              <tr>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4 text-center">Ideas</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Joined</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {filteredUsers.map(user => {
                const ideaCount = getUserIdeaCount(user.User_ID);
                return (
                  <tr
                    key={user.User_ID}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.Avatar}
                          alt={user.Name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <span className="font-bold text-slate-900 dark:text-slate-100 block">
                            {user.Name}
                          </span>
                          <span className="text-[11px] text-slate-400">{user.Department}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400 font-mono">
                      {user.Email}
                    </td>
                    <td className="py-3 px-4">
                      <RoleBadge role={user.Role} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center font-semibold text-slate-800 dark:text-slate-200">
                      {ideaCount}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                          user.Status === 'Active'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            user.Status === 'Active' ? 'bg-emerald-500' : 'bg-slate-400'
                          }`}
                        />
                        {user.Status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500 dark:text-slate-400">
                      {user.Joined}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setTargetUser(user);
                            setNewRole(user.Role);
                            setShowRoleModal(true);
                          }}
                          className="text-xs text-indigo-600 dark:text-indigo-400"
                        >
                          Change Role
                        </Button>

                        <button
                          onClick={() => handleToggleStatus(user)}
                          title={user.Status === 'Active' ? 'Disable User' : 'Enable User'}
                          className={`p-1.5 rounded-lg text-xs font-medium transition-colors ${
                            user.Status === 'Active'
                              ? 'text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950'
                              : 'text-emerald-600 hover:bg-emerald-50'
                          }`}
                        >
                          {user.Status === 'Active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Create User Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New User"
        description="Add a new campus user with an initial role assignment."
      >
        <form onSubmit={handleCreateUser} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Full Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Maya Lin"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="maya.lin@campus.edu"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Role
              </label>
              <select
                value={role}
                onChange={e => setRole(e.target.value as Role)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Student">Student</option>
                <option value="Reviewer">Reviewer</option>
                <option value="Admin">Admin</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Department
              </label>
              <input
                type="text"
                required
                value={department}
                onChange={e => setDepartment(e.target.value)}
                placeholder="e.g. Bioengineering"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowCreateModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md">
              Create User
            </Button>
          </div>
        </form>
      </Modal>

      {/* Change Role Modal */}
      <Modal
        isOpen={showRoleModal}
        onClose={() => setShowRoleModal(false)}
        title="Change User Role"
        description={`Update platform authorization for ${targetUser?.Name}.`}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select New Role
            </label>
            <select
              value={newRole}
              onChange={e => setNewRole(e.target.value as Role)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="Student">Student (Submit, vote, comment)</option>
              <option value="Reviewer">Reviewer (Evaluate & score proposals)</option>
              <option value="Admin">Admin (Full system control & pilot creation)</option>
            </select>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowRoleModal(false)}>
              Cancel
            </Button>
            <Button type="button" variant="primary" size="md" onClick={handleChangeRole}>
              Save Role
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
