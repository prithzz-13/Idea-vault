import React from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '../components/common/Card';
import { Button } from '../components/common/Button';
import {
  Users,
  Lightbulb,
  Clock,
  CheckCircle2,
  FolderKanban,
  TrendingUp,
  ArrowUpRight,
  ShieldCheck,
  Tag,
  BarChart2,
  Award,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';

export const AdminDashboard: React.FC = () => {
  const { setActivePage, openIdeaDetail, openImplementation, dataVersion } = useApp();

  const users = dataService.getUsers();
  const ideas = dataService.getIdeas();
  const reviews = dataService.getReviews();
  const projects = dataService.getProjects();
  const implementations = dataService.getImplementations();
  const categories = dataService.getCategories();

  // Metrics
  const totalUsers = users.length;
  const totalIdeas = ideas.length;
  const pendingReviews = ideas.filter(i => i.Status === 'Under Review' || !reviews.some(r => r.Idea_ID === i.Idea_ID)).length;
  const approvedIdeas = ideas.filter(i => i.Status === 'Selected' || i.Status === 'Project Created' || i.Status === 'Implementation').length;
  const activeProjects = projects.length;
  
  const avgImplementationProgress = implementations.length > 0
    ? Math.round(implementations.reduce((sum, imp) => sum + imp.Progress, 0) / implementations.length)
    : 0;

  // Chart Data 1: Ideas Over Time (Monthly simulation)
  const timelineData = [
    { month: 'May', ideas: 4, evaluated: 2, projects: 1 },
    { month: 'Jun', ideas: 7, evaluated: 5, projects: 2 },
    { month: 'Jul', ideas: 11, evaluated: 8, projects: 3 },
    { month: 'Aug', ideas: 16, evaluated: 12, projects: 4 },
    { month: 'Sep', ideas: 20, evaluated: 15, projects: 5 },
    { month: 'Oct', ideas: 24, evaluated: 18, projects: 6 },
  ];

  // Chart Data 2: Ideas by Category
  const categoryData = categories.map(cat => ({
    name: cat.Category_Name.split('&')[0].trim(),
    count: ideas.filter(i => i.Category_ID === cat.Category_ID).length,
  }));

  // Chart Data 3: Idea Status Distribution (Donut)
  const statusCounts = {
    Submitted: ideas.filter(i => i.Status === 'Submitted').length,
    Discussion: ideas.filter(i => i.Status === 'Discussion').length,
    'Under Review': ideas.filter(i => i.Status === 'Under Review').length,
    Selected: ideas.filter(i => i.Status === 'Selected').length,
    'Needs Revision': ideas.filter(i => i.Status === 'Needs Revision').length,
    Implementation: ideas.filter(i => i.Status === 'Implementation' || i.Status === 'Project Created').length,
  };

  const statusDonutData = [
    { name: 'Submitted', value: statusCounts.Submitted, color: '#94a3b8' },
    { name: 'Discussion', value: statusCounts.Discussion, color: '#6366f1' },
    { name: 'Under Review', value: statusCounts['Under Review'], color: '#f59e0b' },
    { name: 'Selected', value: statusCounts.Selected, color: '#10b981' },
    { name: 'Needs Revision', value: statusCounts['Needs Revision'], color: '#f97316' },
    { name: 'Implementation', value: statusCounts.Implementation, color: '#8b5cf6' },
  ];

  // Chart Data 4: Evaluation Score Distribution
  const scoreBuckets = [
    { range: '6.0 - 6.9', count: reviews.filter(r => r.Overall_Score >= 6.0 && r.Overall_Score < 7.0).length },
    { range: '7.0 - 7.9', count: reviews.filter(r => r.Overall_Score >= 7.0 && r.Overall_Score < 8.0).length },
    { range: '8.0 - 8.9', count: reviews.filter(r => r.Overall_Score >= 8.0 && r.Overall_Score < 9.0).length },
    { range: '9.0 - 10.0', count: reviews.filter(r => r.Overall_Score >= 9.0).length },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header with Quick Admin Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Administration Console
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 mt-1">
            Enterprise Innovation Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Real-time pipeline metrics, department distribution, scoring analytics, and pilot conversion rates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setActivePage('admin-users')}
            leftIcon={<Users className="w-3.5 h-3.5" />}
          >
            Users ({totalUsers})
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setActivePage('admin-categories')}
            leftIcon={<Tag className="w-3.5 h-3.5" />}
          >
            Categories
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => setActivePage('admin-reviews')}
            leftIcon={<ShieldCheck className="w-3.5 h-3.5" />}
          >
            Manage Reviews
          </Button>
        </div>
      </div>

      {/* 6 Top Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center mb-2">
              <Users className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Total Users</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{totalUsers}</h3>
            <span className="text-[10px] text-emerald-600 font-medium">+15 this term</span>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600 flex items-center justify-center mb-2">
              <Lightbulb className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Total Ideas</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{totalIdeas}</h3>
            <span className="text-[10px] text-indigo-600 font-medium">All departments</span>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center mb-2">
              <Clock className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Pending Reviews</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{pendingReviews}</h3>
            <span className="text-[10px] text-amber-600 font-medium">Awaiting score</span>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mb-2">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Approved Ideas</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{approvedIdeas}</h3>
            <span className="text-[10px] text-emerald-600 font-medium">Panel endorsed</span>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center mb-2">
              <FolderKanban className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Active Pilots</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{activeProjects}</h3>
            <span className="text-[10px] text-purple-600 font-medium">Incubator funded</span>
          </CardContent>
        </Card>

        <Card hoverEffect>
          <CardContent className="p-4">
            <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950 text-teal-600 flex items-center justify-center mb-2">
              <TrendingUp className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Impl. Rate</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              {avgImplementationProgress}%
            </h3>
            <span className="text-[10px] text-teal-600 font-medium">Milestones completed</span>
          </CardContent>
        </Card>
      </div>

      {/* Row 1 Charts: Ideas Over Time + Ideas by Category */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Line Chart: Innovation Growth Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Innovation Submissions & Projects Over Time</span>
              <span className="text-xs font-normal text-slate-400">2026 Semester</span>
            </CardTitle>
            <CardDescription>Monthly volume of submitted vs evaluated ideas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="ideas"
                    name="Submissions"
                    stroke="#6366f1"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="evaluated"
                    name="Evaluations"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="projects"
                    name="Projects"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Bar Chart: Ideas by Category */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Ideas Distribution by Category</CardTitle>
            <CardDescription>Proposals across college academic departments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} interval={0} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" name="Proposals" fill="#4f46e5" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Row 2 Charts: Status Distribution Donut + Evaluation Scores Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Distribution Donut */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Lifecycle Status Breakdown</CardTitle>
            <CardDescription>Where campus proposals currently reside</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-56 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusDonutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {statusDonutData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] pt-3 border-t border-slate-100 dark:border-slate-800">
              {statusDonutData.map(item => (
                <div key={item.name} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-600 dark:text-slate-400 truncate">{item.name}</span>
                  <span className="font-bold ml-auto">{item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Score Distribution Bar Chart */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Reviewer Score Distribution</CardTitle>
            <CardDescription>Composite rubric scores awarded by reviewers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={scoreBuckets} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="range" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" name="Evaluations" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="text-center pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
              Mean Score: <strong className="text-slate-800 dark:text-slate-200">8.2 / 10</strong>
            </div>
          </CardContent>
        </Card>

        {/* Implementation Progress Mini Overview */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Active Pilot Progress</span>
              <button
                onClick={() => setActivePage('implementation')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
              >
                Track All
              </button>
            </CardTitle>
            <CardDescription>Live completion status across campus teams</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {implementations.slice(0, 4).map(imp => {
              const proj = projects.find(p => p.Project_ID === imp.Project_ID);
              return (
                <div
                  key={imp.Implementation_ID}
                  onClick={() => openImplementation(imp.Project_ID)}
                  className="cursor-pointer group p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate group-hover:text-indigo-600">
                      {proj?.Project_Name || imp.Project_ID}
                    </span>
                    <span className="font-bold text-indigo-600 dark:text-indigo-400">
                      {imp.Progress}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${imp.Progress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
