import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { IdeaStatus } from '../types';
import { Card, CardContent } from '../components/common/Card';
import { StatusBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import {
  Search,
  Filter,
  SlidersHorizontal,
  ThumbsUp,
  MessageSquare,
  Star,
  Calendar,
  Tag,
  ArrowUpDown,
  Plus,
} from 'lucide-react';

export const DiscoverIdeas: React.FC = () => {
  const { openIdeaDetail, setActivePage, currentUser, dataVersion, triggerRefresh } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'votes' | 'rating' | 'discussed'>('recent');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [page, setPage] = useState(1);
  const itemsPerPage = 8;

  const allIdeas = dataService.getIdeas();
  const categories = dataService.getCategories();
  const reviews = dataService.getReviews();
  const comments = dataService.getComments();
  const votes = dataService.getVotes();

  // Distinct tags
  const allTags = useMemo(() => {
    const set = new Set<string>();
    allIdeas.forEach(i => i.Tags.forEach(t => set.add(t)));
    return Array.from(set).sort();
  }, [allIdeas]);

  // Helpers
  const getCategoryName = (catId: string) => {
    return categories.find(c => c.Category_ID === catId)?.Category_Name || 'General';
  };

  const getAuthor = (userId: string) => {
    return dataService.getUser(userId);
  };

  const getVoteCount = (ideaId: string) => {
    return votes.filter(v => v.Idea_ID === ideaId && v.Vote_Type === 'up').length;
  };

  const getCommentCount = (ideaId: string) => {
    return comments.filter(c => c.Idea_ID === ideaId).length;
  };

  const getReviewScore = (ideaId: string) => {
    const rev = reviews.find(r => r.Idea_ID === ideaId);
    return rev ? rev.Overall_Score : null;
  };

  const handleVote = (e: React.MouseEvent, ideaId: string) => {
    e.stopPropagation();
    dataService.castVote(ideaId, currentUser.User_ID, 'up');
    triggerRefresh();
  };

  // Filter & Sort Logic
  const filteredIdeas = useMemo(() => {
    return allIdeas
      .filter(idea => {
        // Search
        const q = searchTerm.toLowerCase();
        const matchesSearch =
          !q ||
          idea.Title.toLowerCase().includes(q) ||
          idea.Description.toLowerCase().includes(q) ||
          idea.Idea_ID.toLowerCase().includes(q) ||
          idea.Tags.some(t => t.toLowerCase().includes(q));

        // Category
        const matchesCategory = selectedCategory === 'all' || idea.Category_ID === selectedCategory;

        // Status
        const matchesStatus = selectedStatus === 'all' || idea.Status === selectedStatus;

        // Tag
        const matchesTag = selectedTag === 'all' || idea.Tags.includes(selectedTag);

        return matchesSearch && matchesCategory && matchesStatus && matchesTag;
      })
      .sort((a, b) => {
        if (sortBy === 'recent') {
          return new Date(b.Created_Date).getTime() - new Date(a.Created_Date).getTime();
        }
        if (sortBy === 'votes') {
          return getVoteCount(b.Idea_ID) - getVoteCount(a.Idea_ID);
        }
        if (sortBy === 'rating') {
          const scoreA = getReviewScore(a.Idea_ID) || 0;
          const scoreB = getReviewScore(b.Idea_ID) || 0;
          return scoreB - scoreA;
        }
        if (sortBy === 'discussed') {
          return getCommentCount(b.Idea_ID) - getCommentCount(a.Idea_ID);
        }
        return 0;
      });
  }, [allIdeas, searchTerm, selectedCategory, selectedStatus, selectedTag, sortBy, dataVersion]);

  // Pagination
  const totalPages = Math.ceil(filteredIdeas.length / itemsPerPage);
  const paginatedIdeas = filteredIdeas.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Discover Ideas
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Browse, discuss, and support campus innovations across engineering, sustainability, and education.
          </p>
        </div>
        <Button
          variant="primary"
          size="md"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setActivePage('submit')}
        >
          Submit an Idea
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        {/* Top search & sorting row */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              placeholder="Search ideas, categories, tags, or IDs..."
              className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-500 dark:text-slate-400 font-medium">Sort:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="bg-transparent font-semibold text-slate-900 dark:text-slate-100 focus:outline-none cursor-pointer"
              >
                <option value="recent">Most Recent</option>
                <option value="votes">Most Votes</option>
                <option value="rating">Highest Rated</option>
                <option value="discussed">Most Discussed</option>
              </select>
            </div>
          </div>
        </div>

        {/* Filter Pills row */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <span className="text-slate-400 font-medium flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            Filters:
          </span>

          {/* Category Dropdown */}
          <select
            value={selectedCategory}
            onChange={e => {
              setSelectedCategory(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-medium focus:outline-none"
          >
            <option value="all">All Categories ({allIdeas.length})</option>
            {categories.map(cat => (
              <option key={cat.Category_ID} value={cat.Category_ID}>
                {cat.Category_Name}
              </option>
            ))}
          </select>

          {/* Status Dropdown */}
          <select
            value={selectedStatus}
            onChange={e => {
              setSelectedStatus(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-medium focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Submitted">Submitted</option>
            <option value="Discussion">Discussion</option>
            <option value="Under Review">Under Review</option>
            <option value="Selected">Selected</option>
            <option value="Needs Revision">Needs Revision</option>
            <option value="Project Created">Project Created</option>
            <option value="Implementation">Implementation</option>
          </select>

          {/* Popular Tag filter */}
          <select
            value={selectedTag}
            onChange={e => {
              setSelectedTag(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-medium focus:outline-none"
          >
            <option value="all">All Tags</option>
            {allTags.slice(0, 15).map(tag => (
              <option key={tag} value={tag}>
                #{tag}
              </option>
            ))}
          </select>

          {(selectedCategory !== 'all' || selectedStatus !== 'all' || selectedTag !== 'all' || searchTerm) && (
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedStatus('all');
                setSelectedTag('all');
                setSearchTerm('');
              }}
              className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Idea Cards Grid */}
      {filteredIdeas.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center">
          <p className="text-base font-semibold text-slate-700 dark:text-slate-300">
            No ideas match your current filters.
          </p>
          <p className="text-xs text-slate-400 mt-1">
            Try adjusting your search criteria or resetting filters to see more ideas.
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setSelectedCategory('all');
              setSelectedStatus('all');
              setSelectedTag('all');
              setSearchTerm('');
            }}
            className="mt-4"
          >
            Clear All Filters
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {paginatedIdeas.map(idea => {
            const author = getAuthor(idea.User_ID);
            const voteCount = getVoteCount(idea.Idea_ID);
            const commentCount = getCommentCount(idea.Idea_ID);
            const score = getReviewScore(idea.Idea_ID);

            return (
              <Card
                key={idea.Idea_ID}
                hoverEffect
                className="cursor-pointer flex flex-col justify-between"
                onClick={() => openIdeaDetail(idea.Idea_ID)}
              >
                <CardContent className="p-5 flex-1">
                  {/* Top line: Category & Status */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/70 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      {getCategoryName(idea.Category_ID)}
                    </span>
                    <StatusBadge status={idea.Status} size="sm" />
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 transition-colors line-clamp-2">
                    {idea.Title}
                  </h3>

                  {/* Short Description */}
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {idea.Description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 mt-3.5">
                    {idea.Tags.slice(0, 3).map(tag => (
                      <span
                        key={tag}
                        className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                      >
                        #{tag}
                      </span>
                    ))}
                    {idea.Tags.length > 3 && (
                      <span className="text-[10px] text-slate-400 px-1 py-0.5 self-center">
                        +{idea.Tags.length - 3}
                      </span>
                    )}
                  </div>
                </CardContent>

                {/* Footer with Author, Votes, Comments, Score */}
                <div className="p-4 px-5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-2 min-w-0">
                    {author?.Avatar && (
                      <img
                        src={author.Avatar}
                        alt={author.Name}
                        className="w-6 h-6 rounded-full object-cover shrink-0"
                      />
                    )}
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">
                      {author?.Name || 'Anonymous'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    {score !== null && (
                      <span className="flex items-center gap-1 font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded border border-amber-200/60 dark:border-amber-800/60">
                        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                        {score}/10
                      </span>
                    )}

                    <button
                      onClick={e => handleVote(e, idea.Idea_ID)}
                      className="flex items-center gap-1 font-semibold hover:text-indigo-600 dark:hover:text-indigo-400 p-1 rounded transition-colors"
                      title="Vote on this idea"
                    >
                      <ThumbsUp className="w-3.5 h-3.5 text-indigo-500" />
                      <span>{voteCount}</span>
                    </button>

                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{commentCount}</span>
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-slate-200 dark:border-slate-800 pt-4 text-xs">
          <span className="text-slate-500 dark:text-slate-400">
            Showing {(page - 1) * itemsPerPage + 1} to{' '}
            {Math.min(page * itemsPerPage, filteredIdeas.length)} of {filteredIdeas.length} ideas
          </span>
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={page === 1}
              onClick={() => setPage(p => Math.max(1, p - 1))}
            >
              Previous
            </Button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setPage(idx + 1)}
                className={`w-7 h-7 rounded-lg font-semibold transition-colors ${
                  page === idx + 1
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <Button
              variant="outline"
              size="sm"
              disabled={page === totalPages}
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
