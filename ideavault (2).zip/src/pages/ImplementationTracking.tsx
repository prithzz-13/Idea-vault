import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Project, Implementation, ProjectTask, Milestone } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { ProjectStatusBadge, Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  Rocket,
  CheckCircle2,
  Clock,
  Calendar,
  Users,
  Plus,
  Sliders,
  AlertCircle,
  FolderKanban,
  Lightbulb,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const ImplementationTracking: React.FC = () => {
  const { activeProjectId, setActiveProjectId, openIdeaDetail, addToast, triggerRefresh, dataVersion } = useApp();

  const allProjects = dataService.getProjects();
  const currentProjectId = activeProjectId || allProjects[0]?.Project_ID || 'PRJ-2026-001';
  const project = dataService.getProject(currentProjectId);
  const implementation = dataService.getImplementationByProject(currentProjectId);
  const allUsers = dataService.getUsers();

  const owner = project ? allUsers.find(u => u.User_ID === project.Project_Owner_ID) : null;
  const teamMembers = project
    ? allUsers.filter(u => project.Team_Members.includes(u.User_ID))
    : [];

  // Add Task Modal State
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [assigneeId, setAssigneeId] = useState(owner?.User_ID || allUsers[0]?.User_ID || '');
  const [dueDate, setDueDate] = useState('2026-11-01');

  // Milestone toggling
  const handleToggleMilestone = (milestoneId: string) => {
    dataService.toggleMilestone(currentProjectId, milestoneId);
    addToast({ title: 'Milestone Updated', type: 'info' });
    triggerRefresh();
  };

  // Task progress update
  const handleTaskProgressChange = (taskId: string, val: number) => {
    dataService.updateTaskProgress(currentProjectId, taskId, val);
    triggerRefresh();
  };

  // Add Task submit
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    dataService.addTask(currentProjectId, {
      title: taskTitle.trim(),
      assigneeId,
      dueDate,
      progress: 0,
      status: 'Pending',
    });

    setShowTaskModal(false);
    setTaskTitle('');
    addToast({ title: 'Task Added to Sprint', type: 'success' });
    triggerRefresh();
  };

  // Fast progress slider override
  const handleDirectProgressChange = (val: number) => {
    dataService.updateImplementationProgress(currentProjectId, val);
    triggerRefresh();
  };

  if (!project || !implementation) {
    return (
      <div className="text-center py-16">
        <h2 className="text-lg font-bold">No Implementation Project Selected</h2>
      </div>
    );
  }

  const phases: ('Planning' | 'Development' | 'Testing' | 'Deployment')[] = [
    'Planning',
    'Development',
    'Testing',
    'Deployment',
  ];

  return (
    <div className="space-y-8 max-w-6xl mx-auto animate-in fade-in duration-300">
      {/* Top Project Selector & Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
              {project.Project_ID}
            </span>
            <span className="text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Pilot Implementation Tracker
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
            {project.Project_Name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Monitor real-time task completion, sprint deliverables, and production phase milestones.
          </p>
        </div>

        {/* Project Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">Active Pilot:</span>
          <select
            value={currentProjectId}
            onChange={e => setActiveProjectId(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none"
          >
            {allProjects.map(p => (
              <option key={p.Project_ID} value={p.Project_ID}>
                {p.Project_Name}
              </option>
            ))}
          </select>
          <Button
            variant="outline"
            size="sm"
            onClick={() => openIdeaDetail(project.Idea_ID)}
            leftIcon={<Lightbulb className="w-3.5 h-3.5" />}
          >
            Source Idea
          </Button>
        </div>
      </div>

      {/* Progress & Phase Banner (Requirement 16: Progress 68%, Planning -> Development -> Testing -> Deployment) */}
      <Card className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-950 text-white border-indigo-800 shadow-xl overflow-hidden">
        <CardContent className="p-6 sm:p-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest block">
                Overall Implementation Completion
              </span>
              <div className="flex items-baseline gap-3 mt-1">
                <span className="text-5xl font-black text-white">{implementation.Progress}%</span>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  Phase: {project.Project_Status}
                </span>
              </div>
            </div>

            {/* Quick interactive slider to simulate progress changes */}
            <div className="bg-white/10 p-3 rounded-xl border border-white/15 backdrop-blur-md max-w-xs w-full">
              <div className="flex justify-between text-xs text-indigo-200 mb-1 font-semibold">
                <span>Adjust Progress Slider</span>
                <span>{implementation.Progress}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={implementation.Progress}
                onChange={e => handleDirectProgressChange(parseInt(e.target.value))}
                className="w-full accent-indigo-400 cursor-pointer h-2 bg-indigo-950/60 rounded-lg appearance-none"
              />
            </div>
          </div>

          {/* Phase Sequence Timeline: Planning → Development → Testing → Deployment */}
          <div className="pt-4 border-t border-white/10">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              {phases.map((phase, idx) => {
                const phaseOrder = ['Planning', 'Development', 'Testing', 'Deployment'];
                const currentIdx = phaseOrder.indexOf(project.Project_Status);
                const isPassed = idx < currentIdx;
                const isCurrent = idx === currentIdx;

                return (
                  <div
                    key={phase}
                    className={`p-3 rounded-xl border transition-all ${
                      isCurrent
                        ? 'bg-indigo-600/50 border-indigo-400 ring-2 ring-indigo-400/40 text-white font-bold'
                        : isPassed
                        ? 'bg-white/10 border-white/20 text-indigo-200'
                        : 'bg-white/5 border-white/10 text-indigo-400/60'
                    }`}
                  >
                    <div className="text-[10px] font-bold uppercase tracking-wider mb-0.5">
                      Step {idx + 1}
                    </div>
                    <div className="text-sm font-semibold">{phase}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Meta Information Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] text-slate-400 font-semibold uppercase block">
                Project Lead
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate block">
                {owner?.Name || 'Unassigned'}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] text-slate-400 font-semibold uppercase block">
                Start Date
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                {new Date(project.Start_Date).toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] text-slate-400 font-semibold uppercase block">
                Target Launch
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                {new Date(project.Target_End_Date).toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] text-slate-400 font-semibold uppercase block">
                Team Size
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                {project.Team_Members.length + 1} Innovators
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Grid: Milestones on Left, Task Breakdown on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Milestones (5 of 12 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center justify-between">
                <span>Phase Deliverables</span>
                <span className="text-xs font-normal text-slate-400">Click to toggle</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {implementation.Milestones.map(m => (
                <div
                  key={m.id}
                  onClick={() => handleToggleMilestone(m.id)}
                  className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                    m.completed
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/60'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-indigo-400'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={m.completed}
                    onChange={() => {}}
                    className="mt-1 w-4 h-4 text-emerald-600 rounded accent-emerald-600 cursor-pointer"
                  />
                  <div className="flex-1 min-w-0 text-xs">
                    <p
                      className={`font-semibold ${
                        m.completed
                          ? 'line-through text-slate-400 dark:text-slate-500'
                          : 'text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {m.name}
                    </p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                      <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-medium">
                        {m.phase}
                      </span>
                      <span>Due {new Date(m.dueDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Task Breakdown (7 of 12 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base">Sprint Tasks & Workstreams</CardTitle>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Plus className="w-3.5 h-3.5" />}
                onClick={() => setShowTaskModal(true)}
              >
                Add Task
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {implementation.Tasks.map(task => {
                const assignee = allUsers.find(u => u.User_ID === task.assigneeId);
                return (
                  <div
                    key={task.id}
                    className="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900/40 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3 text-xs">
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                          {task.title}
                        </h4>
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                          {assignee && (
                            <span className="font-medium text-slate-600 dark:text-slate-300">
                              {assignee.Name}
                            </span>
                          )}
                          <span>•</span>
                          <span>Due {new Date(task.dueDate).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                          task.status === 'Completed'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : task.status === 'In Progress'
                            ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                            : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        {task.status}
                      </span>
                    </div>

                    {/* Interactive Progress Slider */}
                    <div>
                      <div className="flex justify-between text-[11px] font-semibold text-slate-500 mb-1">
                        <span>Task Completion</span>
                        <span>{task.progress}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={task.progress}
                        onChange={e => handleTaskProgressChange(task.id, parseInt(e.target.value))}
                        className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                      />
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Task Modal */}
      <Modal
        isOpen={showTaskModal}
        onClose={() => setShowTaskModal(false)}
        title="Add Sprint Task"
        description={`Create a new task workstream for "${project.Project_Name}".`}
      >
        <form onSubmit={handleAddTask} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Task Title
            </label>
            <input
              type="text"
              required
              value={taskTitle}
              onChange={e => setTaskTitle(e.target.value)}
              placeholder="e.g. Conduct campus Wi-Fi density load testing"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Assignee
              </label>
              <select
                value={assigneeId}
                onChange={e => setAssigneeId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {allUsers.map(u => (
                  <option key={u.User_ID} value={u.User_ID}>
                    {u.Name} ({u.Role})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Due Date
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={e => setDueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowTaskModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md">
              Add Task
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
