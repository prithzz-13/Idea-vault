import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Idea, User } from '../types';
import { Card } from '../components/common/Card';
import { StatusBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  ShieldCheck,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  Star,
  Calendar,
  Search,
  Filter,
  ArrowRight,
  FolderKanban,
} from 'lucide-react';

export const AdminReviews: React.FC = () => {
  const { openIdeaDetail, openImplementation, addToast, triggerRefresh, dataVersion } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);
  const [selectedReviewerId, setSelectedReviewerId] = useState('');
  const [deadline, setDeadline] = useState('2026-10-25');

  const ideas = dataService.getIdeas();
  const allUsers = dataService.getUsers();
  const reviews = dataService.getReviews();
  const reviewers = allUsers.filter(u => u.Role === 'Reviewer');

  const getReview = (ideaId: string) => reviews.find(r => r.Idea_ID === ideaId);
  const getReviewer = (reviewerId?: string) => allUsers.find(u => u.User_ID === reviewerId);

  const filteredIdeas = ideas.filter(i => {
    const matchesSearch =
      !searchTerm ||
      i.Title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.Idea_ID.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || i.Status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAssign = (idea: Idea) => {
    setSelectedIdea(idea);
    setSelectedReviewerId(idea.Assigned_Reviewer_ID || reviewers[0]?.User_ID || '');
    setShowAssignModal(true);
  };

  const handleConfirmAssignment = () => {
    if (!selectedIdea || !selectedReviewerId) return;

    dataService.assignReviewer(selectedIdea.Idea_ID, selectedReviewerId, `${deadline}T23:59:59Z`);
    setShowAssignModal(false);
    addToast({
      title: 'Reviewer Assigned',
      message: `${selectedIdea.Idea_ID} assigned to reviewer.`,
      type: 'success',
    });
    triggerRefresh();
  };

  const handleApproveIdea = (ideaId: string, title: string) => {
    dataService.updateIdeaStatus(ideaId, 'Selected');
    addToast({
      title: 'Idea Approved & Selected',
      message: `"${title}" has been endorsed for project conversion!`,
      type: 'success',
    });
    triggerRefresh();
  };

  const handleRequestRevision = (ideaId: string, title: string) => {
    dataService.updateIdeaStatus(ideaId, 'Needs Revision');
    addToast({
      title: 'Revision Requested',
      message: `Author of "${title}" notified to provide updated details.`,
      type: 'warning',
    });
    triggerRefresh();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Review & Panel Governance
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Assign academic faculty reviewers, monitor evaluation deadlines, and formally approve ideas.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search proposals or IDs..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm font-semibold focus:outline-none"
        >
          <option value="all">All Stages ({ideas.length})</option>
          <option value="Submitted">Submitted (Unassigned)</option>
          <option value="Under Review">Under Review</option>
          <option value="Selected">Selected / Approved</option>
          <option value="Needs Revision">Needs Revision</option>
          <option value="Project Created">Project Created</option>
          <option value="Implementation">In Implementation</option>
        </select>
      </div>

      {/* Review Management Table (Requirement 14) */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/80 dark:border-slate-800">
              <tr>
                <th className="py-3 px-4">Idea</th>
                <th className="py-3 px-4">Assigned Reviewer</th>
                <th className="py-3 px-4">Submission Date</th>
                <th className="py-3 px-4">Stage Status</th>
                <th className="py-3 px-4 text-center">Score</th>
                <th className="py-3 px-4">Deadline</th>
                <th className="py-3 px-4 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {filteredIdeas.map(idea => {
                const assignedReviewer = getReviewer(idea.Assigned_Reviewer_ID);
                const review = getReview(idea.Idea_ID);

                return (
                  <tr
                    key={idea.Idea_ID}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 max-w-xs">
                      <div
                        onClick={() => openIdeaDetail(idea.Idea_ID)}
                        className="font-bold text-slate-900 dark:text-slate-100 truncate hover:text-indigo-600 cursor-pointer"
                      >
                        {idea.Title}
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">{idea.Idea_ID}</span>
                    </td>
                    <td className="py-3 px-4">
                      {assignedReviewer ? (
                        <div className="flex items-center gap-2">
                          <img
                            src={assignedReviewer.Avatar}
                            alt={assignedReviewer.Name}
                            className="w-6 h-6 rounded-full object-cover"
                          />
                          <div>
                            <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                              {assignedReviewer.Name}
                            </span>
                            <span className="text-[10px] text-slate-400 block truncate max-w-[130px]">
                              {assignedReviewer.Department}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Not Assigned</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {new Date(idea.Created_Date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={idea.Status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center">
                      {review ? (
                        <span className="inline-flex items-center gap-1 font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                          {review.Overall_Score}/10
                        </span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-500 dark:text-slate-400">
                      {idea.Review_Deadline
                        ? new Date(idea.Review_Deadline).toLocaleDateString()
                        : 'Rolling'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenAssign(idea)}
                          className="text-xs"
                        >
                          {idea.Assigned_Reviewer_ID ? 'Reassign' : 'Assign'}
                        </Button>

                        {idea.Status === 'Under Review' && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleApproveIdea(idea.Idea_ID, idea.Title)}
                              className="text-xs text-emerald-600 border-emerald-300 dark:border-emerald-800 hover:bg-emerald-50"
                            >
                              Approve
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRequestRevision(idea.Idea_ID, idea.Title)}
                              className="text-xs text-amber-600 hover:bg-amber-50"
                            >
                              Revision
                            </Button>
                          </>
                        )}

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openIdeaDetail(idea.Idea_ID)}
                          className="text-xs text-indigo-600"
                        >
                          View
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Assign Reviewer Modal */}
      <Modal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        title="Assign Reviewer & Set Evaluation Deadline"
        description={`Assign a faculty reviewer for "${selectedIdea?.Title}".`}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Reviewer
            </label>
            <select
              value={selectedReviewerId}
              onChange={e => setSelectedReviewerId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {reviewers.map(rev => (
                <option key={rev.User_ID} value={rev.User_ID}>
                  {rev.Name} ({rev.Department})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Evaluation Deadline
            </label>
            <input
              type="date"
              value={deadline}
              onChange={e => setDeadline(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowAssignModal(false)}>
              Cancel
            </Button>
            <Button type="button" variant="primary" size="md" onClick={handleConfirmAssignment}>
              Confirm Assignment
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
