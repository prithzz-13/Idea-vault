import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  Sparkles,
  Paperclip,
  Link as LinkIcon,
  CheckCircle2,
  FileText,
  AlertCircle,
  X,
  UploadCloud,
  Rocket,
  ArrowRight,
} from 'lucide-react';

export const SubmitIdea: React.FC = () => {
  const { currentUser, openIdeaDetail, setActivePage, addToast, triggerRefresh } = useApp();

  const categories = dataService.getCategories();

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.Category_ID || 'CAT-001');
  const [tagsInput, setTagsInput] = useState('');
  const [problem, setProblem] = useState('');
  const [solution, setSolution] = useState('');
  const [impact, setImpact] = useState('');
  const [linkInput, setLinkInput] = useState('');
  const [links, setLinks] = useState<string[]>([]);
  const [attachments, setAttachments] = useState<
    Array<{ id: string; name: string; size: string; type: string }>
  >([]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdIdeaId, setCreatedIdeaId] = useState<string | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const handleAddLink = () => {
    if (linkInput.trim()) {
      let url = linkInput.trim();
      if (!url.startsWith('http')) url = 'https://' + url;
      setLinks([...links, url]);
      setLinkInput('');
    }
  };

  const handleRemoveLink = (idx: number) => {
    setLinks(links.filter((_, i) => i !== idx));
  };

  const handleAddMockAttachment = () => {
    const mockFiles = [
      { id: `att-${Date.now()}-1`, name: 'Technical_Feasibility_Spec.pdf', size: '1.4 MB', type: 'application/pdf' },
      { id: `att-${Date.now()}-2`, name: 'Budget_BOM_Estimates.xlsx', size: '128 KB', type: 'application/vnd.ms-excel' },
      { id: `att-${Date.now()}-3`, name: 'Hardware_Schematic_Diagram.png', size: '2.1 MB', type: 'image/png' },
    ];
    const pick = mockFiles[attachments.length % mockFiles.length];
    setAttachments([...attachments, pick]);
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments(attachments.filter(a => a.id !== id));
  };

  const handleSaveDraft = () => {
    addToast({
      title: 'Draft Saved Locally',
      message: 'Your current submission progress has been saved.',
      type: 'info',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !problem.trim() || !solution.trim()) {
      addToast({
        title: 'Validation Error',
        message: 'Please fill in all mandatory fields before submitting.',
        type: 'error',
      });
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const parsedTags = tagsInput
        .split(',')
        .map(t => t.trim().replace(/^#/, ''))
        .filter(t => t.length > 0);

      const newIdea = dataService.createIdea({
        userId: currentUser.User_ID,
        categoryId,
        title: title.trim(),
        description: description.trim() || problem.slice(0, 150),
        problem: problem.trim(),
        solution: solution.trim(),
        impact: impact.trim() || 'Accelerates campus efficiency and sustainability.',
        tags: parsedTags.length > 0 ? parsedTags : ['Innovation', 'Campus'],
        links,
        attachments,
      });

      setIsSubmitting(false);
      setCreatedIdeaId(newIdea.Idea_ID);
      setShowSuccessModal(true);
      triggerRefresh();
    }, 600);
  };

  // Prefill template button for demonstration speed
  const handleLoadDemoTemplate = () => {
    setTitle('Autonomous Campus Quad Snow Removal & Salting Bot');
    setDescription(
      'An autonomous electric mini-robot designed to clear icy sidewalks and dispense eco-friendly brine before morning 8 AM classes.'
    );
    setCategoryId('CAT-001');
    setTagsInput('Robotics, WinterSafety, IoT, Autonomous');
    setProblem(
      'Campus facilities crews struggle to clear 12 miles of pedestrian sidewalks after overnight snowstorms. Slip-and-fall injuries spike by 40% during December and January, causing student fractures and liability.'
    );
    setSolution(
      'Deploy 3 autonomous tracked skid-steer rovers equipped with heated plow blades, rotary bristle brushes, and precise GPS-RTK path tracking. Operates silently overnight powered by rechargeable 48V LiFePO4 batteries.'
    );
    setImpact(
      'Guarantees 100% clear pedestrian corridors before 7:30 AM, reduces salt runoff damage to campus lawns by 60%, and frees manual grounds crew for primary building access.'
    );
    setLinks(['https://safety.campus.edu/winter-reports']);
    setAttachments([
      { id: 'att-demo-1', name: 'Rover_Chassis_CAD.step', size: '3.8 MB', type: 'application/octet-stream' },
    ]);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Submit a New Idea
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Propose a project or innovation for campus review, peer discussion, and incubator funding.
          </p>
        </div>

        <button
          type="button"
          onClick={handleLoadDemoTemplate}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-lg border border-indigo-200 dark:border-indigo-800 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Auto-fill Demo Sample</span>
        </button>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              1. Idea Overview & Classification
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Idea Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                maxLength={100}
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Smart Campus Energy Monitor & Microgrid Controller"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                <span>Be concise, actionable, and clear.</span>
                <span>{title.length}/100</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Primary Category <span className="text-rose-500">*</span>
                </label>
                <select
                  value={categoryId}
                  onChange={e => setCategoryId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {categories.map(cat => (
                    <option key={cat.Category_ID} value={cat.Category_ID}>
                      {cat.Category_Name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={e => setTagsInput(e.target.value)}
                  placeholder="IoT, Sustainability, MachineLearning, Mobile"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Executive Summary / Short Description
              </label>
              <textarea
                rows={2}
                maxLength={250}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="A 2-sentence elevator pitch describing what this idea is and why it matters..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
              />
              <div className="flex justify-end text-[11px] text-slate-400 mt-1">
                <span>{description.length}/250</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section 2: Deep Dive (Problem, Solution, Impact) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Rocket className="w-4 h-4 text-indigo-600" />
              2. Problem, Proposed Solution & Expected Impact
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Problem Statement <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">{problem.length}/1000</span>
              </div>
              <textarea
                required
                rows={3}
                maxLength={1000}
                value={problem}
                onChange={e => setProblem(e.target.value)}
                placeholder="What campus problem are you solving? Who does it affect, and what are the quantifiable costs or inefficiencies today?"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Proposed Solution <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">{solution.length}/1200</span>
              </div>
              <textarea
                required
                rows={3}
                maxLength={1200}
                value={solution}
                onChange={e => setSolution(e.target.value)}
                placeholder="Describe your technical architecture, methodology, hardware or software approach in clear detail..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Expected Impact & Metric Goals <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">{impact.length}/800</span>
              </div>
              <textarea
                required
                rows={3}
                maxLength={800}
                value={impact}
                onChange={e => setImpact(e.target.value)}
                placeholder="Quantifiable returns (e.g. 25% energy savings, 50 hours of admin time eliminated, 1,200 students benefited)..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </CardContent>
        </Card>

        {/* Section 3: Links & Attachments */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Paperclip className="w-4 h-4 text-indigo-600" />
              3. Supporting Documentation & Research
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Supporting Links */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Supporting URLs (GitHub repos, research papers, demos)
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <LinkIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={linkInput}
                    onChange={e => setLinkInput(e.target.value)}
                    placeholder="https://github.com/..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <Button type="button" variant="secondary" size="sm" onClick={handleAddLink}>
                  Add Link
                </Button>
              </div>

              {links.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {links.map((link, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-slate-200 dark:border-slate-700"
                    >
                      <span className="truncate mr-2">{link}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveLink(idx)}
                        className="text-slate-400 hover:text-rose-500"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Attachments */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Attachments (CAD files, PDFs, spreadsheets)
              </label>
              <div
                onClick={handleAddMockAttachment}
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-4 text-center cursor-pointer hover:border-indigo-500 dark:hover:border-indigo-500 transition-colors"
              >
                <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Click to attach project documents or mock CAD files
                </p>
                <p className="text-[11px] text-slate-400">PDF, PNG, JPG, STEP, XLSX up to 25MB</p>
              </div>

              {attachments.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  {attachments.map(att => (
                    <div
                      key={att.id}
                      className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                    >
                      <div className="flex items-center gap-2">
                        <Paperclip className="w-3.5 h-3.5 text-indigo-500" />
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {att.name}
                        </span>
                        <span className="text-[10px] text-slate-400">({att.size})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAttachment(att.id)}
                        className="text-slate-400 hover:text-rose-500"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button type="button" variant="outline" size="md" onClick={handleSaveDraft}>
            Save Draft
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="lg"
            isLoading={isSubmitting}
            rightIcon={<ArrowRight className="w-4 h-4 ml-1" />}
          >
            Submit Idea
          </Button>
        </div>
      </form>

      {/* Success Modal (Requirement 8) */}
      <Modal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        title="Idea Submitted Successfully!"
      >
        <div className="text-center py-4 space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 flex items-center justify-center mx-auto ring-8 ring-emerald-50 dark:ring-emerald-900/30">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div>
            <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              Your idea has been submitted successfully.
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
              Your submission is now published to the IdeaVault campus community. Peer discussion has begun, and faculty reviewers will be assigned.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 max-w-xs mx-auto">
            <span className="text-xs text-slate-400 block font-medium">Assigned Idea Identifier</span>
            <span className="text-lg font-mono font-extrabold text-indigo-600 dark:text-indigo-400 mt-0.5 block">
              {createdIdeaId || 'IV-2026-00124'}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 pt-2 justify-center">
            <Button
              variant="outline"
              size="md"
              onClick={() => {
                setShowSuccessModal(false);
                setActivePage('my-ideas');
              }}
            >
              View in My Ideas
            </Button>
            <Button
              variant="primary"
              size="md"
              onClick={() => {
                setShowSuccessModal(false);
                if (createdIdeaId) openIdeaDetail(createdIdeaId);
              }}
            >
              Open Idea Page
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
