import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { StatusBadge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import {
  ClipboardCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Star,
  Calendar,
  ArrowRight,
} from 'lucide-react';

export const ReviewsQueue: React.FC = () => {
  const { currentUser, openReviewIdea, openIdeaDetail, dataVersion } = useApp();
  const [tab, setTab] = useState<'pending' | 'completed' | 'all'>('pending');

  const allIdeas = dataService.getIdeas();
  const allReviews = dataService.getReviews();
  const allUsers = dataService.getUsers();
  const categories = dataService.getCategories();

  const getCategoryName = (catId: string) =>
    categories.find(c => c.Category_ID === catId)?.Category_Name || 'General';

  const getAuthor = (userId: string) => allUsers.find(u => u.User_ID === userId);
  const getReview = (ideaId: string) => allReviews.find(r => r.Idea_ID === ideaId);

  // Filter ideas based on current reviewer and tab
  const assignedIdeas = allIdeas.filter(
    i => i.Assigned_Reviewer_ID === currentUser.User_ID || currentUser.Role === 'Admin'
  );

  const pendingIdeas = assignedIdeas.filter(i => !getReview(i.Idea_ID) || i.Status === 'Under Review');
  const completedIdeas = allIdeas.filter(i => !!getReview(i.Idea_ID));

  const displayList =
    tab === 'pending'
      ? pendingIdeas
      : tab === 'completed'
      ? completedIdeas
      : allIdeas.filter(i => i.Status === 'Under Review' || i.Status === 'Needs Revision' || !!getReview(i.Idea_ID));

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Review & Evaluation Queue
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Conduct rigorous faculty assessments, provide constructive feedback, and guide project selection.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setTab('pending')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'pending'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Pending Review ({pendingIdeas.length})
          </button>
          <button
            onClick={() => setTab('completed')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'completed'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Completed ({completedIdeas.length})
          </button>
          <button
            onClick={() => setTab('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'all'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            All Campus Reviews
          </button>
        </div>
      </div>

      {/* Review Queue Cards */}
      {displayList.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            All reviews in this category are completed!
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Check back later for new student submissions assigned to your department.
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {displayList.map(idea => {
            const author = getAuthor(idea.User_ID);
            const review = getReview(idea.Idea_ID);

            return (
              <Card key={idea.Idea_ID} hoverEffect className="flex flex-col justify-between">
                <CardContent className="p-5 flex-1 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/70 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      {getCategoryName(idea.Category_ID)}
                    </span>
                    <StatusBadge status={idea.Status} size="sm" />
                  </div>

                  <div>
                    <h3
                      onClick={() => openIdeaDetail(idea.Idea_ID)}
                      className="text-base font-bold text-slate-900 dark:text-slate-100 hover:text-indigo-600 transition-colors cursor-pointer line-clamp-2"
                    >
                      {idea.Title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                      {idea.Description}
                    </p>
                  </div>

                  {author && (
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                      <img
                        src={author.Avatar}
                        alt={author.Name}
                        className="w-6 h-6 rounded-full object-cover"
                      />
                      <span className="text-slate-700 dark:text-slate-300 font-medium truncate">
                        {author.Name} ({author.Department})
                      </span>
                    </div>
                  )}

                  {review && (
                    <div className="p-2.5 rounded-lg bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-xs flex items-center justify-between">
                      <span className="font-semibold text-amber-800 dark:text-amber-200">
                        Score: {review.Overall_Score}/10 • Verdict: {review.Recommendation}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {new Date(review.Created_Date).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                </CardContent>

                <div className="p-4 px-5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-400">{idea.Idea_ID}</span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openIdeaDetail(idea.Idea_ID)}
                    >
                      View Details
                    </Button>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => openReviewIdea(idea.Idea_ID)}
                      rightIcon={<ArrowRight className="w-3.5 h-3.5 ml-1" />}
                    >
                      {review ? 'Edit Scoring' : 'Score Idea'}
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
