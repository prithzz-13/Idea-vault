import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { StatusBadge } from '../components/common/Badge';
import {
  Award,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileText,
  Sliders,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const ReviewEvaluation: React.FC = () => {
  const { activeIdeaId, currentUser, openIdeaDetail, setActivePage, addToast, triggerRefresh } = useApp();

  const idea = dataService.getIdea(activeIdeaId || 'IV-2026-00104');
  const category = idea ? dataService.getCategory(idea.Category_ID) : null;
  const author = idea ? dataService.getUser(idea.User_ID) : null;
  const existingReview = idea ? dataService.getReviewByIdea(idea.Idea_ID) : undefined;

  // Sliders state (1 to 10)
  const [novelty, setNovelty] = useState<number>(existingReview?.Novelty_Score || 8.0);
  const [feasibility, setFeasibility] = useState<number>(existingReview?.Feasibility_Score || 7.5);
  const [impact, setImpact] = useState<number>(existingReview?.Impact_Score || 8.5);
  const [scalability, setScalability] = useState<number>(existingReview?.Scalability_Score || 8.0);
  const [techComplexity, setTechComplexity] = useState<number>(existingReview?.Technical_Complexity_Score || 7.0);

  const [comments, setComments] = useState<string>(
    existingReview?.Comments ||
      'Strong concept with high potential campus value. The technical architecture is well reasoned. Recommend initiating prototype trial.'
  );
  const [recommendation, setRecommendation] = useState<'Recommend' | 'Needs Revision' | 'Reject'>(
    existingReview?.Recommendation || 'Recommend'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Real-time Overall Score calculation
  const compositeScore = parseFloat(
    ((novelty + feasibility + impact + scalability + techComplexity) / 5).toFixed(1)
  );

  if (!idea) {
    return (
      <div className="text-center py-16">
        <h2 className="text-lg font-bold">No Idea Selected For Review</h2>
        <Button variant="primary" size="md" onClick={() => setActivePage('reviews')} className="mt-4">
          Go to Review Queue
        </Button>
      </div>
    );
  }

  const handleSubmitEvaluation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comments.trim()) {
      addToast({ title: 'Please provide reviewer commentary', type: 'error' });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      dataService.submitReview({
        ideaId: idea.Idea_ID,
        reviewerId: currentUser.User_ID,
        novelty,
        feasibility,
        impact,
        scalability,
        technicalComplexity: techComplexity,
        comments: comments.trim(),
        recommendation,
      });

      setIsSubmitting(false);
      addToast({
        title: 'Evaluation Submitted Successfully!',
        message: `Scored ${compositeScore}/10 with verdict: ${recommendation}.`,
        type: 'success',
      });
      triggerRefresh();
      openIdeaDetail(idea.Idea_ID);
    }, 500);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
              {idea.Idea_ID}
            </span>
            <span className="text-xs font-bold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Faculty Evaluation Rubric
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100 mt-1">
            Evaluate Idea: {idea.Title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Review submitted proposal details on the left, score key dimensions on the right, and submit your recommendation.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => openIdeaDetail(idea.Idea_ID)}
        >
          View Full Public Page
        </Button>
      </div>

      {/* 2-Column Split: Idea Info on Left, Evaluation Form on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (5 of 12 cols): Idea Dossier */}
        <div className="lg:col-span-5 space-y-5">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm uppercase tracking-wider text-slate-400 font-bold">
                Proposal Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-xs">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
                  {idea.Title}
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                    {category?.Category_Name}
                  </span>
                  <span>•</span>
                  <StatusBadge status={idea.Status} size="sm" />
                </div>
              </div>

              {author && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl flex items-center gap-3">
                  <img
                    src={author.Avatar}
                    alt={author.Name}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <span className="font-bold text-slate-900 dark:text-slate-100 block">
                      {author.Name}
                    </span>
                    <span className="text-[11px] text-slate-400">{author.Department}</span>
                  </div>
                </div>
              )}

              <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                    Problem Statement:
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed max-h-36 overflow-y-auto">
                    {idea.Problem_Statement}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                    Proposed Solution:
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed max-h-40 overflow-y-auto">
                    {idea.Proposed_Solution}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                    Projected Impact:
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {idea.Expected_Impact}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                    Tags:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {idea.Tags.map(tag => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column (7 of 12 cols): Evaluation Rubric Form */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSubmitEvaluation} className="space-y-6">
            {/* Live Composite Score Banner (Requirement 10) */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-indigo-950 text-white shadow-xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest block">
                  Real-Time Score Preview
                </span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-4xl font-extrabold text-white">{compositeScore}</span>
                  <span className="text-indigo-200 text-sm font-semibold">/ 10.0</span>
                </div>
                <p className="text-xs text-indigo-200 mt-1">
                  Calculated automatically across all 5 evaluation dimensions.
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs font-semibold text-indigo-300 block mb-1">Current Recommendation:</span>
                <span
                  className={`inline-block px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wide ${
                    recommendation === 'Recommend'
                      ? 'bg-emerald-500 text-white'
                      : recommendation === 'Needs Revision'
                      ? 'bg-amber-500 text-white'
                      : 'bg-rose-500 text-white'
                  }`}
                >
                  {recommendation}
                </span>
              </div>
            </div>

            {/* Dimension Sliders Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-indigo-600" />
                  Criteria Scoring (1 - 10)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* 1. Novelty */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
                    <label className="text-slate-800 dark:text-slate-200">
                      1. Novelty & Originality
                    </label>
                    <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                      {novelty.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.1"
                    value={novelty}
                    onChange={e => setNovelty(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Derivative (1.0)</span>
                    <span>Incremental (5.0)</span>
                    <span>Breakthrough (10.0)</span>
                  </div>
                </div>

                {/* 2. Feasibility */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
                    <label className="text-slate-800 dark:text-slate-200">
                      2. Practical Feasibility
                    </label>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                      {feasibility.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.1"
                    value={feasibility}
                    onChange={e => setFeasibility(parseFloat(e.target.value))}
                    className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Impractical (1.0)</span>
                    <span>Challenging (5.0)</span>
                    <span>Readily Viable (10.0)</span>
                  </div>
                </div>

                {/* 3. Impact */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
                    <label className="text-slate-800 dark:text-slate-200">
                      3. Campus & Academic Impact
                    </label>
                    <span className="font-mono text-amber-600 dark:text-amber-400 font-bold text-sm">
                      {impact.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.1"
                    value={impact}
                    onChange={e => setImpact(parseFloat(e.target.value))}
                    className="w-full accent-amber-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Negligible (1.0)</span>
                    <span>Moderate (5.0)</span>
                    <span>Transformational (10.0)</span>
                  </div>
                </div>

                {/* 4. Scalability */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
                    <label className="text-slate-800 dark:text-slate-200">
                      4. Scalability & Transferability
                    </label>
                    <span className="font-mono text-purple-600 dark:text-purple-400 font-bold text-sm">
                      {scalability.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.1"
                    value={scalability}
                    onChange={e => setScalability(parseFloat(e.target.value))}
                    className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Niche (1.0)</span>
                    <span>Departmental (5.0)</span>
                    <span>Campus-wide (10.0)</span>
                  </div>
                </div>

                {/* 5. Technical Rigor */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
                    <label className="text-slate-800 dark:text-slate-200">
                      5. Technical Rigor & Architecture
                    </label>
                    <span className="font-mono text-sky-600 dark:text-sky-400 font-bold text-sm">
                      {techComplexity.toFixed(1)} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.1"
                    value={techComplexity}
                    onChange={e => setTechComplexity(parseFloat(e.target.value))}
                    className="w-full accent-sky-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Superficial (1.0)</span>
                    <span>Standard (5.0)</span>
                    <span>Exceptional (10.0)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recommendation & Comments Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Reviewer Commentary & Verdict</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Recommendation Radio Pills */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Formal Recommendation <span className="text-rose-500">*</span>
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      type="button"
                      onClick={() => setRecommendation('Recommend')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                        recommendation === 'Recommend'
                          ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                      <span>Recommend</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRecommendation('Needs Revision')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                        recommendation === 'Needs Revision'
                          ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 ring-2 ring-amber-500/20'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <AlertTriangle className="w-5 h-5 text-amber-500" />
                      <span>Needs Revision</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRecommendation('Reject')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                        recommendation === 'Reject'
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 ring-2 ring-rose-500/20'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <XCircle className="w-5 h-5 text-rose-500" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>

                {/* Reviewer Commentary */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Evaluation Commentary & Constructive Guidance <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={comments}
                    onChange={e => setComments(e.target.value)}
                    placeholder="Provide specific feedback on methodology, budget feasibility, potential hurdles, and suggestions for refinement..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="md"
                    onClick={() => openIdeaDetail(idea.Idea_ID)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    size="lg"
                    isLoading={isSubmitting}
                    rightIcon={<ArrowRight className="w-4 h-4 ml-1" />}
                  >
                    Submit Evaluation
                  </Button>
                </div>
              </CardContent>
            </Card>
          </form>
        </div>
      </div>
    </div>
  );
};
