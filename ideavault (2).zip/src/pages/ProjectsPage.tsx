import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { ProjectStatusBadge, Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import {
  FolderKanban,
  Rocket,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Plus,
} from 'lucide-react';

export const ProjectsPage: React.FC = () => {
  const { openImplementation, openIdeaDetail, currentUser, addToast, triggerRefresh, dataVersion } = useApp();

  const projects = dataService.getProjects();
  const implementations = dataService.getImplementations();
  const allUsers = dataService.getUsers();
  const ideas = dataService.getIdeas();

  // Create Project Modal state (when user clicks "New Project Pilot")
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedIdeaId, setSelectedIdeaId] = useState('');
  const [projectName, setProjectName] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [targetEndDate, setTargetEndDate] = useState('2026-12-15');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High' | 'Critical'>('High');

  // Eligible ideas for conversion (Selected or Under Review)
  const eligibleIdeas = ideas.filter(
    i => i.Status === 'Selected' || i.Status === 'Under Review' || !projects.some(p => p.Idea_ID === i.Idea_ID)
  );

  const getOwner = (ownerId: string) => allUsers.find(u => u.User_ID === ownerId);
  const getImpl = (projectId: string) => implementations.find(i => i.Project_ID === projectId);

  const handleOpenCreateModal = () => {
    if (eligibleIdeas.length > 0) {
      setSelectedIdeaId(eligibleIdeas[0].Idea_ID);
      setProjectName(`${eligibleIdeas[0].Title} Pilot`);
    }
    setShowCreateModal(true);
  };

  const handleSelectIdeaChange = (ideaId: string) => {
    setSelectedIdeaId(ideaId);
    const idObj = ideas.find(i => i.Idea_ID === ideaId);
    if (idObj) {
      setProjectName(`${idObj.Title} Pilot`);
    }
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIdeaId || !projectName.trim()) return;

    const sourceIdea = ideas.find(i => i.Idea_ID === selectedIdeaId);
    const result = dataService.createProjectFromIdea({
      ideaId: selectedIdeaId,
      projectName: projectName.trim(),
      projectOwnerId: sourceIdea?.User_ID || currentUser.User_ID,
      teamMembers: [currentUser.User_ID],
      startDate,
      targetEndDate,
      description: sourceIdea?.Proposed_Solution || 'Campus implementation project.',
      priority,
    });

    setShowCreateModal(false);
    addToast({
      title: 'Project Created',
      message: `Project ${result.project.Project_ID} is now active.`,
      type: 'success',
    });
    triggerRefresh();
    openImplementation(result.project.Project_ID);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Innovation Projects & Pilots
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track funded ideas transitioning into technical pilots, hardware builds, and campus rollouts.
          </p>
        </div>

        {currentUser.Role === 'Admin' && (
          <Button
            variant="primary"
            size="md"
            leftIcon={<Plus className="w-4 h-4" />}
            onClick={handleOpenCreateModal}
          >
            Create New Project
          </Button>
        )}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map(proj => {
          const owner = getOwner(proj.Project_Owner_ID);
          const impl = getImpl(proj.Project_ID);
          const progress = impl ? impl.Progress : 0;
          const sourceIdea = ideas.find(i => i.Idea_ID === proj.Idea_ID);

          return (
            <Card
              key={proj.Project_ID}
              hoverEffect
              className="cursor-pointer flex flex-col justify-between"
              onClick={() => openImplementation(proj.Project_ID)}
            >
              <CardContent className="p-6 flex-1 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                    {proj.Project_ID}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                        proj.Priority === 'Critical'
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                          : proj.Priority === 'High'
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                      }`}
                    >
                      {proj.Priority} Priority
                    </span>
                    <ProjectStatusBadge status={proj.Project_Status} size="sm" />
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 transition-colors">
                    {proj.Project_Name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {proj.Description}
                  </p>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold mb-1">
                    <span className="text-slate-600 dark:text-slate-400">Implementation Progress</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-bold">{progress}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Team & Owner */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    {owner && (
                      <img
                        src={owner.Avatar}
                        alt={owner.Name}
                        className="w-6 h-6 rounded-full object-cover"
                      />
                    )}
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Lead: {owner?.Name || 'Unassigned'}
                    </span>
                  </div>

                  <span className="text-slate-400">
                    Target: {new Date(proj.Target_End_Date).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>

              <div className="p-4 px-6 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">
                  Source: {sourceIdea?.Idea_ID || 'Direct'}
                </span>
                <span className="font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Track Implementation <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Admin Convert Idea into Project Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New Project Pilot"
        description="Select an approved innovation idea and provision an implementation tracker."
      >
        <form onSubmit={handleCreateProject} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Source Idea
            </label>
            <select
              value={selectedIdeaId}
              onChange={e => handleSelectIdeaChange(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {eligibleIdeas.map(id => (
                <option key={id.Idea_ID} value={id.Idea_ID}>
                  {id.Idea_ID} — {id.Title} ({id.Status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Project Name
            </label>
            <input
              type="text"
              required
              value={projectName}
              onChange={e => setProjectName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Start Date
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Target Completion Date
              </label>
              <input
                type="date"
                required
                value={targetEndDate}
                onChange={e => setTargetEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Priority Level
            </label>
            <select
              value={priority}
              onChange={e => setPriority(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
              <option value="Critical">Critical</option>
            </select>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" size="md" onClick={() => setShowCreateModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md">
              Create Project
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
