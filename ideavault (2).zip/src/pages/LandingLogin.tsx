import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import { Sparkles, ArrowRight, ShieldCheck, UserCheck, GraduationCap, CheckCircle2, Lightbulb, Compass, Award } from 'lucide-react';
import { Button } from '../components/common/Button';

export const LandingLogin: React.FC = () => {
  const { loginAs, addToast } = useApp();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<Role>('Student');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegister) {
      addToast({
        title: 'Registration Successful',
        message: `Welcome to IdeaVault, ${name || 'User'}!`,
        type: 'success',
      });
      loginAs(role);
    } else {
      loginAs('Student');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <header className="h-20 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md px-6 sm:px-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              IdeaVault
            </span>
            <span className="text-[11px] text-slate-400 block font-medium">
              Enterprise Innovation Hub
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
          >
            {isRegister ? 'Already have an account? Sign In' : 'Need an account? Register'}
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex flex-col lg:flex-row items-stretch max-w-7xl mx-auto w-full p-6 sm:p-12 gap-12 lg:gap-16 justify-center">
        {/* Left Column: Value Proposition & Workflow */}
        <div className="flex-1 flex flex-col justify-center space-y-8 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200/70 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-xs font-semibold w-fit">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Campus & Enterprise Idea Lifecycle Platform</span>
          </div>

          <div>
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 leading-[1.15]">
              Turn ideas into <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-indigo-400">impact.</span>
            </h1>
            <p className="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-400 leading-relaxed font-normal">
              IdeaVault centralizes the end-to-end innovation pipeline: from peer brainstorming and faculty scoring, to incubator selection and milestone project tracking.
            </p>
          </div>

          {/* Lifecycle Visual Bar */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              The 5-Step Lifecycle
            </div>
            <div className="grid grid-cols-5 gap-2 text-center text-xs font-semibold text-slate-700 dark:text-slate-300">
              <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                1. Submit
              </div>
              <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                2. Discuss
              </div>
              <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                3. Evaluate
              </div>
              <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                4. Select
              </div>
              <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                5. Track
              </div>
            </div>
          </div>

          {/* Quick Demo Switcher Cards */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Instant Demo Access (No Password Needed)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => loginAs('Student')}
                className="flex flex-col items-start p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-500 hover:ring-2 hover:ring-indigo-500/20 transition-all text-left group"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center mb-2">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                  Student
                </span>
                <span className="text-[11px] text-slate-400 mt-0.5">Submit, vote, comment</span>
              </button>

              <button
                type="button"
                onClick={() => loginAs('Reviewer')}
                className="flex flex-col items-start p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-purple-500 hover:ring-2 hover:ring-purple-500/20 transition-all text-left group"
              >
                <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center mb-2">
                  <UserCheck className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-purple-600 dark:group-hover:text-purple-400">
                  Reviewer
                </span>
                <span className="text-[11px] text-slate-400 mt-0.5">Score & evaluate ideas</span>
              </button>

              <button
                type="button"
                onClick={() => loginAs('Admin')}
                className="flex flex-col items-start p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-amber-500 hover:ring-2 hover:ring-amber-500/20 transition-all text-left group"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center mb-2">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-amber-600 dark:group-hover:text-amber-400">
                  Admin
                </span>
                <span className="text-[11px] text-slate-400 mt-0.5">Manage & track pilots</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Auth Card */}
        <div className="flex-1 flex flex-col justify-center max-w-md w-full">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xl">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                {isRegister ? 'Create an Account' : 'Sign in to IdeaVault'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {isRegister
                  ? 'Join campus researchers, innovators, and mentors.'
                  : 'Enter your credentials to access your dashboard.'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegister && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. David Kim"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Role
                    </label>
                    <select
                      value={role}
                      onChange={e => setRole(e.target.value as Role)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="Student">Student / Innovator</option>
                      <option value="Reviewer">Faculty Reviewer</option>
                      <option value="Admin">Platform Administrator</option>
                    </select>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@campus.edu"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Password
                  </label>
                  {!isRegister && (
                    <a href="#forgot" className="text-[11px] font-medium text-indigo-600 hover:underline">
                      Forgot?
                    </a>
                  )}
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <Button type="submit" variant="primary" size="lg" className="w-full mt-2">
                <span>{isRegister ? 'Register & Enter Platform' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </form>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white dark:bg-slate-900 px-3 text-slate-400 font-semibold">
                  Or continue with demo
                </span>
              </div>
            </div>

            <Button
              type="button"
              variant="outline"
              size="md"
              className="w-full"
              onClick={() => loginAs('Student')}
            >
              <GraduationCap className="w-4 h-4 text-indigo-600" />
              <span>Continue as Demo Student (Aarav)</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-6 border-t border-slate-200/80 dark:border-slate-800 text-center text-xs text-slate-400">
        IdeaVault Prototype • Designed for Academic & Enterprise Innovation Lifecycle Demonstration
      </footer>
    </div>
  );
};
