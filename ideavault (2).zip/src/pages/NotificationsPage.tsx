import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { dataService } from '../services/dataService';
import { Card, CardHeader, CardTitle, CardContent } from '../components/common/Card';
import { Button } from '../components/common/Button';
import {
  Bell,
  CheckCheck,
  CheckCircle2,
  ThumbsUp,
  MessageSquare,
  Award,
  Rocket,
  Info,
  ArrowRight,
} from 'lucide-react';

export const NotificationsPage: React.FC = () => {
  const { currentUser, openIdeaDetail, openImplementation, addToast, triggerRefresh, dataVersion } = useApp();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const notifications = dataService.getNotifications(currentUser.User_ID);
  const filtered = filter === 'unread' ? notifications.filter(n => !n.Read) : notifications;

  const handleMarkAllRead = () => {
    dataService.markAllNotificationsRead(currentUser.User_ID);
    addToast({ title: 'All notifications marked as read', type: 'info' });
    triggerRefresh();
  };

  const handleItemClick = (link?: string, id?: string) => {
    if (id) dataService.markNotificationRead(id);
    if (!link) return;

    if (link.startsWith('idea/')) {
      openIdeaDetail(link.replace('idea/', ''));
    } else if (link.startsWith('projects/')) {
      openImplementation(link.replace('projects/', ''));
    } else if (link.startsWith('review/')) {
      openIdeaDetail(link.replace('review/', ''));
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'vote':
        return <ThumbsUp className="w-4 h-4 text-indigo-500" />;
      case 'comment':
        return <MessageSquare className="w-4 h-4 text-blue-500" />;
      case 'review':
        return <Award className="w-4 h-4 text-amber-500" />;
      case 'project':
        return <Rocket className="w-4 h-4 text-purple-500" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Notification Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Stay updated on review scores, student discussions, and project status milestones.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                filter === 'all'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                filter === 'unread'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Unread ({notifications.filter(n => !n.Read).length})
            </button>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={handleMarkAllRead}
            leftIcon={<CheckCheck className="w-3.5 h-3.5" />}
          >
            Mark all read
          </Button>
        </div>
      </div>

      {/* Notifications List */}
      <Card>
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <Bell className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No notifications to display
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              You are all caught up on your ideas and project events.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {filtered.map(notif => (
              <div
                key={notif.Notification_ID}
                onClick={() => handleItemClick(notif.Link, notif.Notification_ID)}
                className={`p-4 sm:p-5 flex items-start gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors ${
                  !notif.Read ? 'bg-indigo-50/30 dark:bg-indigo-950/20' : ''
                }`}
              >
                <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                  {getIcon(notif.Type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {notif.Title}
                    </h4>
                    <span className="text-[11px] text-slate-400 shrink-0">
                      {new Date(notif.Created_Date).toLocaleDateString()} at{' '}
                      {new Date(notif.Created_Date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                    {notif.Message}
                  </p>

                  {notif.Link && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 mt-2 hover:underline">
                      View details <ArrowRight className="w-3 h-3" />
                    </span>
                  )}
                </div>

                {!notif.Read && (
                  <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 shrink-0 mt-2" />
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};
