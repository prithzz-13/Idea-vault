export type Role = 'Student' | 'Reviewer' | 'Admin';

export type IdeaStatus = 
  | 'Submitted' 
  | 'Discussion' 
  | 'Under Review' 
  | 'Needs Revision'
  | 'Selected' 
  | 'Rejected'
  | 'Project Created' 
  | 'Implementation';

export interface User {
  User_ID: string;
  Name: string;
  Email: string;
  Password?: string;
  Role: Role;
  Avatar: string;
  Department: string;
  Title?: string;
  Status: 'Active' | 'Inactive';
  Joined: string;
}

export interface Category {
  Category_ID: string;
  Category_Name: string;
  Description: string;
  Color: string;
  Icon: string;
}

export interface Attachment {
  id: string;
  name: string;
  size: string;
  type: string;
  url?: string;
}

export interface Idea {
  Idea_ID: string; // e.g. "IV-2026-00101"
  User_ID: string;
  Category_ID: string;
  Title: string;
  Description: string;
  Problem_Statement: string;
  Proposed_Solution: string;
  Expected_Impact: string;
  Tags: string[];
  Supporting_Links: string[];
  Attachments: Attachment[];
  Status: IdeaStatus;
  Created_Date: string;
  Updated_Date: string;
  Assigned_Reviewer_ID?: string;
  Review_Deadline?: string;
}

export interface Review {
  Review_ID: string;
  Idea_ID: string;
  Reviewer_ID: string;
  Novelty_Score: number;       // 1 - 10
  Feasibility_Score: number;   // 1 - 10
  Impact_Score: number;        // 1 - 10
  Scalability_Score: number;   // 1 - 10
  Technical_Complexity_Score: number; // 1 - 10
  Overall_Score: number;       // Computed average
  Comments: string;
  Recommendation: 'Recommend' | 'Needs Revision' | 'Reject';
  Created_Date: string;
}

export interface Comment {
  Comment_ID: string;
  Idea_ID: string;
  User_ID: string;
  Comment_Text: string;
  Comment_Date: string;
  Parent_Comment_ID?: string;
}

export interface Vote {
  Vote_ID: string;
  Idea_ID: string;
  User_ID: string;
  Vote_Type: 'up' | 'down';
  Created_Date: string;
}

export type ProjectStatus = 'Planning' | 'Development' | 'Testing' | 'Deployment' | 'Completed';
export type ProjectPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface Project {
  Project_ID: string;
  Idea_ID: string;
  Project_Name: string;
  Project_Status: ProjectStatus;
  Project_Owner_ID: string;
  Team_Members: string[]; // User_IDs
  Start_Date: string;
  Target_End_Date: string;
  Description: string;
  Priority: ProjectPriority;
}

export interface ProjectTask {
  id: string;
  title: string;
  assigneeId: string;
  dueDate: string;
  progress: number; // 0 - 100
  status: 'Pending' | 'In Progress' | 'Completed';
}

export interface Milestone {
  id: string;
  name: string;
  phase: 'Planning' | 'Development' | 'Testing' | 'Deployment';
  completed: boolean;
  dueDate: string;
}

export interface Implementation {
  Implementation_ID: string;
  Project_ID: string;
  Progress: number; // 0 - 100
  Start_Date: string;
  End_Date: string;
  Milestones: Milestone[];
  Tasks: ProjectTask[];
  Last_Updated: string;
}

export interface Notification {
  Notification_ID: string;
  User_ID: string;
  Title: string;
  Message: string;
  Type: 'vote' | 'comment' | 'review' | 'status' | 'project' | 'system';
  Link?: string;
  Read: boolean;
  Created_Date: string;
}

export interface Activity {
  Activity_ID: string;
  User_ID: string;
  Idea_ID?: string;
  Project_ID?: string;
  Type: 'vote' | 'comment' | 'review' | 'status' | 'project' | 'create';
  Message: string;
  Created_Date: string;
}
