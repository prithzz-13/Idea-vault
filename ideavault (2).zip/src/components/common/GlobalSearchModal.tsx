import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { dataService } from '../../services/dataService';
import { Search, Lightbulb, FolderKanban, Users, Tag, ArrowRight, X } from 'lucide-react';
import { StatusBadge, RoleBadge } from './Badge';

export const GlobalSearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, openIdeaDetail, openImplementation, dataVersion } = useApp();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'ideas' | 'projects' | 'users' | 'categories'>('all');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isSearchOpen]);

  const results = useMemo(() => {
    if (!query.trim()) {
      return {
        ideas: dataService.getIdeas().slice(0, 3),
        projects: dataService.getProjects().slice(0, 2),
        users: dataService.getUsers().slice(0, 3),
        categories: dataService.getCategories().slice(0, 4),
      };
    }

    const q = query.toLowerCase().trim();
    const ideas = dataService.getIdeas().filter(
      i =>
        i.Title.toLowerCase().includes(q) ||
        i.Description.toLowerCase().includes(q) ||
        i.Idea_ID.toLowerCase().includes(q) ||
        i.Tags.some(t => t.toLowerCase().includes(q))
    );

    const projects = dataService.getProjects().filter(
      p =>
        p.Project_Name.toLowerCase().includes(q) ||
        p.Description.toLowerCase().includes(q) ||
        p.Project_ID.toLowerCase().includes(q)
    );

    const users = dataService.getUsers().filter(
      u =>
        u.Name.toLowerCase().includes(q) ||
        u.Email.toLowerCase().includes(q) ||
        u.Department.toLowerCase().includes(q) ||
        u.Role.toLowerCase().includes(q)
    );

    const categories = dataService.getCategories().filter(
      c =>
        c.Category_Name.toLowerCase().includes(q) ||
        c.Description.toLowerCase().includes(q)
    );

    return { ideas, projects, users, categories };
  }, [query, dataVersion]);

  if (!isSearchOpen) return null;

  const totalResults =
    results.ideas.length + results.projects.length + results.users.length + results.categories.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 overflow-y-auto">
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={() => setIsSearchOpen(false)}
      />

      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden z-10">
        {/* Search Input Box */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 gap-3">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search ideas, projects, users, tags..."
            className="flex-1 bg-transparent border-0 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none text-base font-normal"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="hidden sm:inline-flex text-[11px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
            ESC to close
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 text-xs">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              activeTab === 'all'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            All ({totalResults})
          </button>
          <button
            onClick={() => setActiveTab('ideas')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              activeTab === 'ideas'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            Ideas ({results.ideas.length})
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              activeTab === 'projects'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            Projects ({results.projects.length})
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              activeTab === 'users'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            Users ({results.users.length})
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              activeTab === 'categories'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            Categories ({results.categories.length})
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4">
          {totalResults === 0 ? (
            <div className="text-center py-10">
              <Lightbulb className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-600 dark:text-slate-300">No results found</p>
              <p className="text-xs text-slate-400 mt-1">Try searching for keywords like "energy", "solar", "drone", or "campus"</p>
            </div>
          ) : (
            <>
              {/* Ideas */}
              {(activeTab === 'all' || activeTab === 'ideas') && results.ideas.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Lightbulb className="w-3.5 h-3.5" />
                    Ideas
                  </h4>
                  <div className="space-y-1.5">
                    {results.ideas.map(idea => (
                      <div
                        key={idea.Idea_ID}
                        onClick={() => {
                          setIsSearchOpen(false);
                          openIdeaDetail(idea.Idea_ID);
                        }}
                        className="group flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors"
                      >
                        <div className="flex-1 min-w-0 pr-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono text-slate-400">{idea.Idea_ID}</span>
                            <span className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                              {idea.Title}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                            {idea.Description}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <StatusBadge status={idea.Status} size="sm" />
                          <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 transition-colors" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Projects */}
              {(activeTab === 'all' || activeTab === 'projects') && results.projects.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <FolderKanban className="w-3.5 h-3.5" />
                    Projects
                  </h4>
                  <div className="space-y-1.5">
                    {results.projects.map(proj => (
                      <div
                        key={proj.Project_ID}
                        onClick={() => {
                          setIsSearchOpen(false);
                          openImplementation(proj.Project_ID);
                        }}
                        className="group flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors"
                      >
                        <div className="flex-1 min-w-0 pr-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono text-slate-400">{proj.Project_ID}</span>
                            <span className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                              {proj.Project_Name}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                            {proj.Description}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs font-medium px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded">
                            {proj.Project_Status}
                          </span>
                          <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 transition-colors" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Users */}
              {(activeTab === 'all' || activeTab === 'users') && results.users.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" />
                    People
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {results.users.map(user => (
                      <div
                        key={user.User_ID}
                        className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-50/50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800"
                      >
                        <img
                          src={user.Avatar}
                          alt={user.Name}
                          className="w-8 h-8 rounded-full object-cover shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                            {user.Name}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">{user.Department}</p>
                        </div>
                        <RoleBadge role={user.Role} size="sm" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Categories */}
              {(activeTab === 'all' || activeTab === 'categories') && results.categories.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5" />
                    Categories
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {results.categories.map(cat => (
                      <div
                        key={cat.Category_ID}
                        className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                      >
                        {cat.Category_Name}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
