import React from 'react';
import { IdeaStatus } from '../../types';
import { CheckCircle2, Circle, Clock, Rocket, ThumbsUp, FileText, ClipboardCheck, ArrowRight } from 'lucide-react';

interface StatusTimelineProps {
  status: IdeaStatus;
  interactive?: boolean;
  onSelectStage?: (status: IdeaStatus) => void;
}

export const StatusTimeline: React.FC<StatusTimelineProps> = ({ status, interactive = false, onSelectStage }) => {
  // Lifecycle sequence:
  // 1. Submit (Submitted)
  // 2. Discuss (Discussion)
  // 3. Evaluate (Under Review / Needs Revision)
  // 4. Select (Selected / Rejected)
  // 5. Track (Project Created / Implementation)

  const stages: {
    key: string;
    label: string;
    description: string;
    associatedStatus: IdeaStatus;
    icon: React.ReactNode;
  }[] = [
    {
      key: 'submit',
      label: 'Submit',
      description: 'Idea proposed & logged',
      associatedStatus: 'Submitted',
      icon: <FileText className="w-4 h-4" />,
    },
    {
      key: 'discuss',
      label: 'Discuss',
      description: 'Peer feedback & votes',
      associatedStatus: 'Discussion',
      icon: <ThumbsUp className="w-4 h-4" />,
    },
    {
      key: 'evaluate',
      label: 'Evaluate',
      description: 'Faculty scoring & review',
      associatedStatus: 'Under Review',
      icon: <ClipboardCheck className="w-4 h-4" />,
    },
    {
      key: 'select',
      label: 'Select',
      description: 'Approved for incubator',
      associatedStatus: 'Selected',
      icon: <CheckCircle2 className="w-4 h-4" />,
    },
    {
      key: 'track',
      label: 'Track',
      description: 'Pilot build & milestones',
      associatedStatus: 'Implementation',
      icon: <Rocket className="w-4 h-4" />,
    },
  ];

  const getStageRank = (st: IdeaStatus): number => {
    switch (st) {
      case 'Submitted':
        return 0;
      case 'Discussion':
        return 1;
      case 'Under Review':
      case 'Needs Revision':
        return 2;
      case 'Selected':
      case 'Rejected':
        return 3;
      case 'Project Created':
      case 'Implementation':
        return 4;
      default:
        return 0;
    }
  };

  const currentRank = getStageRank(status);

  return (
    <div className="w-full py-4">
      <div className="flex items-center justify-between relative">
        {/* Connecting Line */}
        <div className="absolute top-1/2 left-6 right-6 -translate-y-1/2 h-1 bg-slate-200 dark:bg-slate-800 -z-0" />
        <div
          className="absolute top-1/2 left-6 -translate-y-1/2 h-1 bg-indigo-600 transition-all duration-500 -z-0"
          style={{ width: `${(currentRank / (stages.length - 1)) * 92}%` }}
        />

        {stages.map((stage, idx) => {
          const isDone = idx < currentRank;
          const isCurrent = idx === currentRank;
          const isPending = idx > currentRank;

          return (
            <div
              key={stage.key}
              onClick={() => interactive && onSelectStage && onSelectStage(stage.associatedStatus)}
              className={`flex flex-col items-center relative z-10 group ${
                interactive ? 'cursor-pointer' : ''
              }`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 font-semibold text-xs shadow-sm ${
                  isDone
                    ? 'bg-indigo-600 text-white'
                    : isCurrent
                    ? 'bg-indigo-600 text-white ring-4 ring-indigo-100 dark:ring-indigo-950/80 scale-110'
                    : 'bg-white dark:bg-slate-900 border-2 border-slate-300 dark:border-slate-700 text-slate-400'
                }`}
              >
                {stage.icon}
              </div>

              <div className="text-center mt-2.5">
                <span
                  className={`text-xs font-bold block ${
                    isCurrent
                      ? 'text-indigo-600 dark:text-indigo-400'
                      : isDone
                      ? 'text-slate-800 dark:text-slate-200'
                      : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {stage.label}
                </span>
                <span className="hidden sm:block text-[11px] text-slate-400 dark:text-slate-500 max-w-[90px] leading-tight mt-0.5">
                  {stage.description}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {status === 'Needs Revision' && (
        <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-lg text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2">
          <Clock className="w-4 h-4 shrink-0 text-amber-600" />
          <span>This idea is marked <strong>Needs Revision</strong>. The author can revise details based on reviewer feedback.</span>
        </div>
      )}

      {status === 'Rejected' && (
        <div className="mt-4 p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 rounded-lg text-xs text-rose-800 dark:text-rose-200 flex items-center gap-2">
          <Circle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>This idea was evaluated and not selected for this cycle. Feedback is preserved in the review history.</span>
        </div>
      )}
    </div>
  );
};
