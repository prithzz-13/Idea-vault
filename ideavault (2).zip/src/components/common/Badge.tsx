import React from 'react';
import { IdeaStatus, Role, ProjectStatus } from '../../types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'outline' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'amber';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  className = '',
}) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-medium',
    md: 'text-xs px-2.5 py-1 font-semibold',
    lg: 'text-sm px-3 py-1 font-semibold',
  };

  const variantClasses = {
    default: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700',
    outline: 'border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 bg-transparent',
    success: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
    warning: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
    danger: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
    info: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800',
    purple: 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800',
    amber: 'bg-orange-50 text-orange-700 dark:bg-orange-950/60 dark:text-orange-300 border border-orange-200 dark:border-orange-800',
  };

  return (
    <span
      className={`inline-flex items-center rounded-full transition-colors ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </span>
  );
};

export const StatusBadge: React.FC<{ status: IdeaStatus; size?: 'sm' | 'md' | 'lg' }> = ({ status, size = 'md' }) => {
  switch (status) {
    case 'Submitted':
      return <Badge variant="default" size={size}><span className="w-1.5 h-1.5 rounded-full bg-slate-400 mr-1.5 animate-pulse" />Submitted</Badge>;
    case 'Discussion':
      return <Badge variant="info" size={size}><span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mr-1.5" />Discussion</Badge>;
    case 'Under Review':
      return <Badge variant="warning" size={size}><span className="w-1.5 h-1.5 rounded-full bg-amber-500 mr-1.5 animate-ping" />Under Review</Badge>;
    case 'Needs Revision':
      return <Badge variant="amber" size={size}><span className="w-1.5 h-1.5 rounded-full bg-orange-500 mr-1.5" />Needs Revision</Badge>;
    case 'Selected':
      return <Badge variant="success" size={size}><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5" />Selected</Badge>;
    case 'Rejected':
      return <Badge variant="danger" size={size}><span className="w-1.5 h-1.5 rounded-full bg-rose-500 mr-1.5" />Rejected</Badge>;
    case 'Project Created':
      return <Badge variant="purple" size={size}><span className="w-1.5 h-1.5 rounded-full bg-purple-500 mr-1.5" />Project Created</Badge>;
    case 'Implementation':
      return <Badge variant="success" size={size}><span className="w-1.5 h-1.5 rounded-full bg-teal-500 mr-1.5 animate-pulse" />Implementation</Badge>;
    default:
      return <Badge size={size}>{status}</Badge>;
  }
};

export const RoleBadge: React.FC<{ role: Role; size?: 'sm' | 'md' }> = ({ role, size = 'sm' }) => {
  switch (role) {
    case 'Student':
      return <Badge variant="info" size={size}>Student</Badge>;
    case 'Reviewer':
      return <Badge variant="purple" size={size}>Reviewer</Badge>;
    case 'Admin':
      return <Badge variant="warning" size={size}>Admin</Badge>;
    default:
      return <Badge size={size}>{role}</Badge>;
  }
};

export const ProjectStatusBadge: React.FC<{ status: ProjectStatus; size?: 'sm' | 'md' }> = ({ status, size = 'sm' }) => {
  switch (status) {
    case 'Planning':
      return <Badge variant="default" size={size}>Planning</Badge>;
    case 'Development':
      return <Badge variant="info" size={size}>Development</Badge>;
    case 'Testing':
      return <Badge variant="warning" size={size}>Testing</Badge>;
    case 'Deployment':
      return <Badge variant="purple" size={size}>Deployment</Badge>;
    case 'Completed':
      return <Badge variant="success" size={size}>Completed</Badge>;
    default:
      return <Badge size={size}>{status}</Badge>;
  }
};
