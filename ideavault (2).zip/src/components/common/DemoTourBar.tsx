import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  CheckCircle2,
  ChevronRight,
  ChevronDown,
  Sparkles,
  X,
  Play,
  RotateCcw,
} from 'lucide-react';
import { Role } from '../../types';

export const DemoTourBar: React.FC = () => {
  const {
    currentUser,
    switchRole,
    activePage,
    setActivePage,
    activeIdeaId,
    openIdeaDetail,
    openReviewIdea,
    openImplementation,
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const steps = [
    {
      num: 1,
      title: 'Student Dashboard',
      desc: 'Explore campus stats & submit button',
      action: () => {
        switchRole('Student');
        setActivePage('dashboard');
      },
    },
    {
      num: 2,
      title: 'Submit New Proposal',
      desc: 'Multi-section form with auto-fill demo',
      action: () => {
        switchRole('Student');
        setActivePage('submit');
      },
    },
    {
      num: 3,
      title: 'View In My Ideas',
      desc: 'Verify submission in author inventory',
      action: () => {
        switchRole('Student');
        setActivePage('my-ideas');
      },
    },
    {
      num: 4,
      title: 'Idea Discussion & AI',
      desc: 'Open idea, vote, comment, view AI Insights',
      action: () => {
        openIdeaDetail('IV-2026-00104');
      },
    },
    {
      num: 5,
      title: 'Switch to Reviewer',
      desc: 'Review queue & rubric evaluations',
      action: () => {
        switchRole('Reviewer');
        setActivePage('reviews');
      },
    },
    {
      num: 6,
      title: 'Score Idea (1-10 Rubric)',
      desc: 'Interactive sliders & live composite score',
      action: () => {
        openReviewIdea('IV-2026-00104');
      },
    },
    {
      num: 7,
      title: 'Switch to Admin',
      desc: 'Enterprise analytics & Recharts distribution',
      action: () => {
        switchRole('Admin');
        setActivePage('analytics');
      },
    },
    {
      num: 8,
      title: 'Approve & Project Pilot',
      desc: 'Select idea & allocate implementation budget',
      action: () => {
        switchRole('Admin');
        setActivePage('admin-reviews');
      },
    },
    {
      num: 9,
      title: 'Implementation Tracker',
      desc: 'Real-time progress, milestones & task sliders',
      action: () => {
        openImplementation('PRJ-2026-001');
      },
    },
  ];

  return (
    <div className="fixed bottom-4 left-4 z-40">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xl border border-slate-700 dark:border-slate-200 text-xs font-bold hover:scale-105 transition-all group"
        >
          <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400 group-hover:rotate-12 transition-transform" />
          <span>Demo Journey Guide</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 dark:bg-slate-900/20 font-mono">
            {currentStep}/9
          </span>
        </button>
      ) : (
        <div className="w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-3">
          <div className="flex items-center justify-between p-3.5 bg-gradient-to-r from-indigo-900 to-indigo-950 text-white">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400" />
              <h4 className="text-xs font-bold">17-Step Demo Guide (End-to-End)</h4>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-300 hover:text-white p-1 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-3 max-h-72 overflow-y-auto space-y-1.5">
            {steps.map(s => {
              const isCurrent = currentStep === s.num;
              return (
                <div
                  key={s.num}
                  onClick={() => {
                    setCurrentStep(s.num);
                    s.action();
                  }}
                  className={`flex items-start gap-2.5 p-2 rounded-xl cursor-pointer text-xs transition-all ${
                    isCurrent
                      ? 'bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-800'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5 ${
                      isCurrent
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {s.num}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-900 dark:text-slate-100">{s.title}</p>
                    <p className="text-[11px] text-slate-400 leading-tight">{s.desc}</p>
                  </div>
                  {isCurrent && <Play className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-1" />}
                </div>
              );
            })}
          </div>

          <div className="p-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between text-xs">
            <button
              onClick={() => {
                const next = currentStep < steps.length ? currentStep + 1 : 1;
                setCurrentStep(next);
                steps[next - 1].action();
              }}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-semibold flex items-center gap-1 hover:bg-indigo-700"
            >
              <span>Next Step ({currentStep < 9 ? currentStep + 1 : 1})</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] text-slate-400">Click any step to jump</span>
          </div>
        </div>
      )}
    </div>
  );
};
