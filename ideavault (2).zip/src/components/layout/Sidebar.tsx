import React from 'react';
import { useApp, ActivePage } from '../../context/AppContext';
import { Role } from '../../types';
import {
  LayoutDashboard,
  Compass,
  FileEdit,
  ClipboardCheck,
  FolderKanban,
  Rocket,
  BarChart3,
  Bell,
  Settings,
  Users,
  Tag,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Lightbulb,
} from 'lucide-react';
import { RoleBadge } from '../common/Badge';

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isCollapsed,
  setIsCollapsed,
  mobileOpen,
  setMobileOpen,
}) => {
  const { currentUser, activePage, setActivePage, switchRole } = useApp();

  const handleNav = (page: ActivePage) => {
    setActivePage(page);
    setMobileOpen(false);
  };

  // Build role-tailored navigation items
  const studentNavItems: { label: string; icon: React.ReactNode; page: ActivePage }[] = [
    { label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, page: 'dashboard' },
    { label: 'Discover Ideas', icon: <Compass className="w-5 h-5" />, page: 'discover' },
    { label: 'My Ideas', icon: <Lightbulb className="w-5 h-5" />, page: 'my-ideas' },
    { label: 'Submit Idea', icon: <FileEdit className="w-5 h-5" />, page: 'submit' },
    { label: 'Reviews', icon: <ClipboardCheck className="w-5 h-5" />, page: 'reviews' },
    { label: 'Projects', icon: <FolderKanban className="w-5 h-5" />, page: 'projects' },
    { label: 'Implementation', icon: <Rocket className="w-5 h-5" />, page: 'implementation' },
    { label: 'Analytics', icon: <BarChart3 className="w-5 h-5" />, page: 'analytics' },
    { label: 'Notifications', icon: <Bell className="w-5 h-5" />, page: 'notifications' },
    { label: 'Settings', icon: <Settings className="w-5 h-5" />, page: 'settings' },
  ];

  const reviewerNavItems: { label: string; icon: React.ReactNode; page: ActivePage }[] = [
    { label: 'Review Queue', icon: <ClipboardCheck className="w-5 h-5" />, page: 'reviews' },
    { label: 'Discover Ideas', icon: <Compass className="w-5 h-5" />, page: 'discover' },
    { label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, page: 'dashboard' },
    { label: 'Projects', icon: <FolderKanban className="w-5 h-5" />, page: 'projects' },
    { label: 'Implementation', icon: <Rocket className="w-5 h-5" />, page: 'implementation' },
    { label: 'Analytics', icon: <BarChart3 className="w-5 h-5" />, page: 'analytics' },
    { label: 'Notifications', icon: <Bell className="w-5 h-5" />, page: 'notifications' },
    { label: 'Settings', icon: <Settings className="w-5 h-5" />, page: 'settings' },
  ];

  const adminNavItems: { label: string; icon: React.ReactNode; page: ActivePage }[] = [
    { label: 'Admin Dashboard', icon: <BarChart3 className="w-5 h-5" />, page: 'analytics' },
    { label: 'Discover Ideas', icon: <Compass className="w-5 h-5" />, page: 'discover' },
    { label: 'Users Management', icon: <Users className="w-5 h-5" />, page: 'admin-users' },
    { label: 'Categories', icon: <Tag className="w-5 h-5" />, page: 'admin-categories' },
    { label: 'Review Management', icon: <ShieldCheck className="w-5 h-5" />, page: 'admin-reviews' },
    { label: 'Projects', icon: <FolderKanban className="w-5 h-5" />, page: 'projects' },
    { label: 'Implementation', icon: <Rocket className="w-5 h-5" />, page: 'implementation' },
    { label: 'Submit Idea', icon: <FileEdit className="w-5 h-5" />, page: 'submit' },
    { label: 'Notifications', icon: <Bell className="w-5 h-5" />, page: 'notifications' },
    { label: 'Settings', icon: <Settings className="w-5 h-5" />, page: 'settings' },
  ];

  const currentNav =
    currentUser.Role === 'Admin'
      ? adminNavItems
      : currentUser.Role === 'Reviewer'
      ? reviewerNavItems
      : studentNavItems;

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200/80 dark:border-slate-800 transition-all duration-300 ${
          isCollapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div
            className="flex items-center gap-3 cursor-pointer overflow-hidden"
            onClick={() => handleNav(currentUser.Role === 'Admin' ? 'analytics' : 'dashboard')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            {!isCollapsed && (
              <div className="min-w-0">
                <span className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  IdeaVault
                  <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                    Pro
                  </span>
                </span>
                <p className="text-[11px] text-slate-400 font-medium truncate">Innovation Platform</p>
              </div>
            )}
          </div>

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* User Card Pill in Sidebar */}
        {!isCollapsed ? (
          <div className="mx-3 mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-800 flex items-center gap-3 shrink-0">
            <img
              src={currentUser.Avatar}
              alt={currentUser.Name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/20"
            />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                {currentUser.Name}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <RoleBadge role={currentUser.Role} size="sm" />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center mt-3 shrink-0">
            <img
              src={currentUser.Avatar}
              alt={currentUser.Name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-indigo-500/20"
              title={`${currentUser.Name} (${currentUser.Role})`}
            />
          </div>
        )}

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {currentNav.map(item => {
            const isActive = activePage === item.page;
            return (
              <button
                key={item.label}
                onClick={() => handleNav(item.page)}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all duration-150 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/20 font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'
                } ${isCollapsed ? 'justify-center px-0' : ''}`}
              >
                <span className={`shrink-0 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`}>
                  {item.icon}
                </span>
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </div>

        {/* Quick Role Switcher (Crucial Requirement) */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 shrink-0 bg-slate-50/50 dark:bg-slate-900/50">
          {!isCollapsed ? (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Demo Role Switcher
                </span>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">1-Click</span>
              </div>
              <div className="grid grid-cols-3 gap-1 bg-slate-200/70 dark:bg-slate-800 p-1 rounded-lg">
                {(['Student', 'Reviewer', 'Admin'] as Role[]).map(role => (
                  <button
                    key={role}
                    onClick={() => switchRole(role)}
                    className={`py-1 text-xs font-semibold rounded-md transition-all ${
                      currentUser.Role === role
                        ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5">
              {(['Student', 'Reviewer', 'Admin'] as Role[]).map(role => (
                <button
                  key={role}
                  onClick={() => switchRole(role)}
                  title={`Switch to ${role}`}
                  className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center transition-colors ${
                    currentUser.Role === role
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {role[0]}
                </button>
              ))}
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
