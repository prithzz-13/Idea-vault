import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { TopNavbar } from './components/layout/TopNavbar';
import { ToastContainer } from './components/common/ToastContainer';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { DemoTourBar } from './components/common/DemoTourBar';

// Pages
import { LandingLogin } from './pages/LandingLogin';
import { StudentDashboard } from './pages/StudentDashboard';
import { DiscoverIdeas } from './pages/DiscoverIdeas';
import { MyIdeas } from './pages/MyIdeas';
import { SubmitIdea } from './pages/SubmitIdea';
import { IdeaDetails } from './pages/IdeaDetails';
import { ReviewEvaluation } from './pages/ReviewEvaluation';
import { ReviewsQueue } from './pages/ReviewsQueue';
import { ProjectsPage } from './pages/ProjectsPage';
import { ImplementationTracking } from './pages/ImplementationTracking';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminUsers } from './pages/AdminUsers';
import { AdminCategories } from './pages/AdminCategories';
import { AdminReviews } from './pages/AdminReviews';
import { NotificationsPage } from './pages/NotificationsPage';
import { SettingsPage } from './pages/SettingsPage';

const AppContent: React.FC = () => {
  const { activePage, isAuthenticated } = useApp();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // If not logged in, show polished landing/login screen
  if (!isAuthenticated || activePage === 'login' || activePage === 'register') {
    return (
      <>
        <LandingLogin />
        <ToastContainer />
      </>
    );
  }

  // Active page renderer
  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <StudentDashboard />;
      case 'discover':
        return <DiscoverIdeas />;
      case 'my-ideas':
        return <MyIdeas />;
      case 'submit':
        return <SubmitIdea />;
      case 'idea-detail':
        return <IdeaDetails />;
      case 'evaluate-idea':
        return <ReviewEvaluation />;
      case 'reviews':
        return <ReviewsQueue />;
      case 'projects':
        return <ProjectsPage />;
      case 'implementation':
        return <ImplementationTracking />;
      case 'analytics':
        return <AdminDashboard />;
      case 'admin-users':
        return <AdminUsers />;
      case 'admin-categories':
        return <AdminCategories />;
      case 'admin-reviews':
        return <AdminReviews />;
      case 'notifications':
        return <NotificationsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <StudentDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      {/* Persistent Sidebar */}
      <Sidebar
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
        mobileOpen={mobileMenuOpen}
        setMobileOpen={setMobileMenuOpen}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ${
          isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'
        }`}
      >
        {/* Sticky Top Navbar */}
        <TopNavbar onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} />

        {/* Dynamic Page Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-24">
          {renderPage()}
        </main>
      </div>

      {/* Global Utilities */}
      <GlobalSearchModal />
      <ToastContainer />
      <DemoTourBar />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
