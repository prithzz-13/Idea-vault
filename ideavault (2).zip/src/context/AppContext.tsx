import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';
import { dataService } from '../services/dataService';

export type ActivePage = 
  | 'dashboard'
  | 'discover'
  | 'my-ideas'
  | 'submit'
  | 'idea-detail'
  | 'evaluate-idea'
  | 'reviews'
  | 'projects'
  | 'implementation'
  | 'analytics'
  | 'notifications'
  | 'settings'
  | 'admin-users'
  | 'admin-categories'
  | 'admin-reviews'
  | 'login'
  | 'register';

export interface ToastMessage {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

interface AppContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  switchRole: (role: Role) => void;
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  activeIdeaId: string | null;
  setActiveIdeaId: (id: string | null) => void;
  activeProjectId: string | null;
  setActiveProjectId: (id: string | null) => void;
  openIdeaDetail: (ideaId: string) => void;
  openReviewIdea: (ideaId: string) => void;
  openImplementation: (projectId: string) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
  dataVersion: number;
  triggerRefresh: () => void;
  isAuthenticated: boolean;
  logout: () => void;
  loginAs: (role: Role) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const users = dataService.getUsers();
  const defaultStudent = users.find(u => u.Role === 'Student') || users[0];
  
  const [currentUser, setCurrentUser] = useState<User>(defaultStudent);
  const [activePage, setActivePage] = useState<ActivePage>('dashboard');
  const [activeIdeaId, setActiveIdeaId] = useState<string | null>('IV-2026-00101');
  const [activeProjectId, setActiveProjectId] = useState<string | null>('PRJ-2026-001');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [dataVersion, setDataVersion] = useState<number>(1);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);

  // Sync dark class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Global Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const triggerRefresh = () => {
    setDataVersion(v => v + 1);
  };

  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  const switchRole = (role: Role) => {
    const allUsers = dataService.getUsers();
    const targetUser = allUsers.find(u => u.Role === role) || allUsers[0];
    setCurrentUser(targetUser);
    
    // Sensible landing page for role
    if (role === 'Student') {
      setActivePage('dashboard');
    } else if (role === 'Reviewer') {
      setActivePage('reviews');
    } else if (role === 'Admin') {
      setActivePage('analytics');
    }
    
    addToast({
      title: `Switched to ${role} Mode`,
      message: `Simulating experience as ${targetUser.Name} (${targetUser.Department})`,
      type: 'info',
    });
    triggerRefresh();
  };

  const loginAs = (role: Role) => {
    setIsAuthenticated(true);
    switchRole(role);
  };

  const logout = () => {
    setIsAuthenticated(false);
    setActivePage('login');
    addToast({
      title: 'Logged Out',
      message: 'You have been signed out of IdeaVault.',
      type: 'info',
    });
  };

  const openIdeaDetail = (ideaId: string) => {
    setActiveIdeaId(ideaId);
    setActivePage('idea-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openReviewIdea = (ideaId: string) => {
    setActiveIdeaId(ideaId);
    setActivePage('evaluate-idea');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openImplementation = (projectId: string) => {
    setActiveProjectId(projectId);
    setActivePage('implementation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        switchRole,
        activePage,
        setActivePage,
        activeIdeaId,
        setActiveIdeaId,
        activeProjectId,
        setActiveProjectId,
        openIdeaDetail,
        openReviewIdea,
        openImplementation,
        theme,
        toggleTheme,
        isSearchOpen,
        setIsSearchOpen,
        toasts,
        addToast,
        removeToast,
        dataVersion,
        triggerRefresh,
        isAuthenticated,
        logout,
        loginAs,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
