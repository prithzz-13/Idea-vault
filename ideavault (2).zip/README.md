# IdeaVault — AI-Powered Innovation & Idea Lifecycle Platform

**Turn ideas into impact.**

IdeaVault centralizes the complete lifecycle of campus and enterprise innovation:
$$\text{SUBMIT} \longrightarrow \text{DISCUSS} \longrightarrow \text{EVALUATE} \longrightarrow \text{SELECT} \longrightarrow \text{TRACK}$$

---

## 🚀 Live Prototype Highlights

- **Vite + React 18 + TypeScript + Tailwind CSS**
- **Clean Service / Data Layer** (`src/services/dataService.ts`) with a fully normalized relational schema (`USER`, `IDEA`, `CATEGORY`, `REVIEW`, `COMMENT`, `VOTE`, `PROJECT`, `IMPLEMENTATION`, `NOTIFICATION`, `ACTIVITY`) persisting into `localStorage`.
- **Pre-populated with rich, realistic demo data**:
  - 15 Users across Students, Faculty Reviewers, and Administrators
  - 20 Detailed Campus Innovation Proposals
  - 6 Academic Categories (Technology & AI, Sustainability & Green Tech, Education & Learning, Healthcare & Wellness, Campus Life & Community, Business & Social Innovation)
  - 10 Structured Faculty Rubric Reviews
  - 30 Discussion Comments & Threaded Replies
  - 55 Community Upvotes
  - 5 Active Pilot Projects & Implementation Workstreams
- **Interactive 1-Click Role Switcher**: Instant switching between **Student**, **Reviewer**, and **Admin** personas anywhere in the interface.
- **Floating Demo Tour Guide**: Bottom-left guide that steps through the 17-step end-to-end evaluation and pilot conversion journey.
- **Global Search**: `Ctrl + K` / `Cmd + K` instant search modal across Ideas, Projects, Users, and Categories.
- **Dual Visual Theme**: Light and Dark mode with automatic system font rendering (Plus Jakarta Sans).

---

## 🛠 Tech Stack

- **Framework**: React 18 & TypeScript
- **Bundler**: Vite 6
- **Styling**: Tailwind CSS with custom design system tokens
- **Icons**: Lucide React
- **Data Visualizations**: Recharts (LineChart, BarChart, PieChart donut, CartesianGrid)
- **Local Storage Engine**: Synchronized singleton mock database with 1-click seed reset.

---

## 🧭 Key Features & Workflows

### 1. SUBMIT — Structured Proposal Intake
- Multi-section form: Classification, Problem Statement, Technical Solution, Expected Impact, Supporting Links, and File Attachments.
- Live character counters and client validation.
- One-click **Auto-fill Demo Sample** button for lightning-fast presentations.
- Generates official Idea IDs (e.g. `IV-2026-00124`) with an interactive success dialog.

### 2. DISCUSS — Community Peer Feedback & Voting
- Real-time upvoting/downvoting with instantaneous state and tally updates.
- Threaded peer comments with reply nesting and timestamped faculty interactions.
- Tag taxonomy and category filtering.

### 3. EVALUATE — Faculty Rubric Scoring
- 5-criteria slider rubric (Novelty, Feasibility, Campus Impact, Scalability, Technical Rigor) scored from 1.0 to 10.0.
- Live composite score preview and automatic recommendation categorization (*Recommend*, *Needs Revision*, *Reject*).
- Reviewer commentary and faculty audit history.

### 4. SELECT — Administrative Governance
- Review management dashboard displaying assigned reviewers, deadlines, and composite ratings.
- 1-click **Approve & Convert to Project Pilot** dialog specifying milestones, project owner, and target launch dates.

### 5. TRACK — Implementation & Milestone Management
- Full pilot tracking view (`PRJ-2026-001: Smart Campus Energy Monitor Pilot`).
- Phase lifecycle: **Planning → Development → Testing → Deployment**.
- Interactive milestone deliverable checkboxes that dynamically recalculate the overall completion percentage.
- Task workstream cards with real-time completion sliders and status badges.

### 6. AI Insights Engine (Simulated)
- Semantic similarity detection calculating overlap percentages with existing campus proposals.
- Duplicate detection warning flags to prevent redundant funding.
- Automatic executive summaries and suggested taxonomy tags.

---

## 🧑‍💻 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run the Vite development server
npm run dev

# 3. Build production bundle
npm run build
```

Open [http://localhost:5173](http://localhost:5173) in your browser.
